import React from 'react';

interface CommentModalProps {
  show: boolean;
  comment: string | null;
  skuCode: string;
  onClose: () => void;
}

const CommentModal: React.FC<CommentModalProps> = ({ show, comment, skuCode, onClose }) => {
  if (!show) return null;
  
  return (
    <div style={{
      position: 'fixed', 
      top: 0, 
      left: 0, 
      right: 0, 
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.5)', 
      zIndex: 9999, 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      backdropFilter: 'blur(2px)'
    }}>
      <div style={{ 
        background: '#ffffff', 
        borderRadius: 12, 
        minWidth: 480, 
        maxWidth: 640,
        maxHeight: '85vh',
        boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3), 0 8px 25px rgba(0, 0, 0, 0.2)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        animation: 'modalSlideIn 0.3s ease-out'
      }}>
        {/* Header */}
        <div style={{ 
          background: 'rgb(48, 234, 3)',
          padding: '20px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '2px solid rgb(48, 234, 3)'
        }}>
          <div style={{ 
            display: 'flex',
            alignItems: 'center',
            gap: 12
          }}>
            <div style={{
              width: 40,
              height: 40,
              borderRadius: '50%',
              background: 'rgba(0, 0, 0, 0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <i className="ri-message-3-line" style={{ fontSize: 20, color: '#000000' }}></i>
            </div>
            <div>
              <h3 style={{ 
                margin: 0, 
                fontSize: 18, 
                fontWeight: 600,
                color: '#000000'
              }}>
                SKU Comment
              </h3>
              <p style={{ 
                margin: 0, 
                fontSize: 14, 
                color: 'rgba(0, 0, 0, 0.7)',
                fontWeight: 400
              }}>
                {skuCode}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            style={{
              background: 'rgba(0, 0, 0, 0.1)',
              border: 'none',
              borderRadius: '50%',
              width: 32,
              height: 32,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(0, 0, 0, 0.2)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(0, 0, 0, 0.1)';
            }}
          >
            <i className="ri-close-line" style={{ fontSize: 16, color: '#000000' }}></i>
          </button>
        </div>
        
        {/* Content */}
        <div style={{ 
          flex: 1,
          padding: '24px',
          display: 'flex',
          flexDirection: 'column'
        }}>
          {comment && comment.trim() ? (
            <div style={{ 
              background: '#f8f9fa',
              border: '1px solid #e9ecef',
              borderRadius: 8,
              padding: '20px',
              minHeight: 120,
              maxHeight: 300,
              overflowY: 'auto',
              position: 'relative'
            }}>
              <div style={{
                position: 'absolute',
                top: 8,
                right: 8,
                background: '#28a745',
                color: '#ffffff',
                padding: '4px 8px',
                borderRadius: 12,
                fontSize: 11,
                fontWeight: 600,
                textTransform: 'uppercase',
                letterSpacing: '0.5px'
              }}>
                Comment Available
              </div>
              <div style={{ 
                whiteSpace: 'pre-wrap',
                wordWrap: 'break-word',
                lineHeight: 1.6,
                color: '#333',
                fontSize: 14,
                marginTop: 20
              }}>
                {comment}
              </div>
            </div>
          ) : (
            <div style={{ 
              background: '#f8f9fa',
              border: '2px dashed #dee2e6',
              borderRadius: 8,
              padding: '40px 20px',
              textAlign: 'center',
              minHeight: 120,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <div style={{
                width: 60,
                height: 60,
                borderRadius: '50%',
                background: '#e9ecef',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 16
              }}>
                <i className="ri-message-3-line" style={{ fontSize: 24, color: '#6c757d' }}></i>
              </div>
              <h4 style={{ 
                margin: '0 0 8px 0',
                fontSize: 16,
                fontWeight: 600,
                color: '#495057'
              }}>
                No Comment Available
              </h4>
              <p style={{ 
                margin: 0,
                fontSize: 14,
                color: '#6c757d',
                lineHeight: 1.5
              }}>
                This SKU doesn't have any comments yet.
              </p>
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div style={{ 
          padding: '16px 24px',
          background: '#f8f9fa',
          borderTop: '1px solid #e9ecef',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: 12
        }}>
          <button 
            onClick={onClose} 
            style={{ 
              padding: '10px 24px', 
              borderRadius: 6, 
              border: '1px solid #dee2e6',
              background: '#ffffff', 
              color: '#495057', 
              fontWeight: 500, 
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              fontSize: 14
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#f8f9fa';
              e.currentTarget.style.borderColor = '#adb5bd';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#ffffff';
              e.currentTarget.style.borderColor = '#dee2e6';
            }}
          >
            Close
          </button>
        </div>
      </div>
      
      <style>{`
        @keyframes modalSlideIn {
          from {
            opacity: 0;
            transform: translateY(-20px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
      `}</style>
    </div>
  );
};

export default CommentModal;
