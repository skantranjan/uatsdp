import React, { ReactNode } from 'react';
import { MsalProvider } from '@azure/msal-react';
import { PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from '../config/msalConfig';

// Create MSAL instance
const msalInstance = new PublicClientApplication(msalConfig);

interface SSOProviderProps {
  children: ReactNode;
}

const SSOProvider: React.FC<SSOProviderProps> = ({ children }) => {
  return (
    <MsalProvider instance={msalInstance}>
      {children}
    </MsalProvider>
  );
};

export default SSOProvider;
