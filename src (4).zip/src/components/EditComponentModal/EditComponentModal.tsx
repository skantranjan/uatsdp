import React, { useState, useEffect } from 'react';
import { apiPut, apiPost, apiPostFormData, apiGetNoAuth, apiGet } from '../../utils/api';
import MultiSelect from '../MultiSelect';

interface EditComponentModalProps {
  show: boolean;
  onClose: () => void;
  component: any;
  onSuccess: () => void;
}

interface EditComponentData {
  componentType: string;
  componentCode: string;
  componentDescription: string;
  componentCategory: string;
  componentQuantity: string;
  componentUnitOfMeasure: string;
  componentBaseQuantity: string;
  componentBaseUnitOfMeasure: string;
  wW: string;
  componentPackagingType: string;
  componentPackagingMaterial: string;
  componentUnitWeight: string;
  componentWeightUnitOfMeasure: string;
  percentPostConsumer: string;
  percentPostIndustrial: string;
  percentChemical: string;
  percentBioSourced: string;
  materialStructure: string;
  packagingColour: string;
  packagingLevel: string;
  componentDimensions: string;
  packagingEvidence: File[];
  validityFrom: string;
  validityTo: string;
  chPack?: string;
  kpisEvidenceMapping?: string;
  browseFiles?: File[];
  componentPackagingLevel?: string;
  evidenceChemicalRecycled?: File[];
}

interface EditComponentErrors {
  componentType: string;
  componentCode: string;
  componentDescription: string;
  componentCategory: string;
  componentQuantity: string;
  componentUnitOfMeasure: string;
  componentBaseQuantity: string;
  componentBaseUnitOfMeasure: string;
  wW: string;
  componentPackagingType: string;
  componentPackagingMaterial: string;
  componentUnitWeight: string;
  componentWeightUnitOfMeasure: string;
  percentPostConsumer: string;
  percentPostIndustrial: string;
  percentChemical: string;
  percentBioSourced: string;
  materialStructure: string;
  packagingColour: string;
  packagingLevel: string;
  componentDimensions: string;
  validityFrom: string;
  validityTo: string;
  percentageSum: string;
  general?: string;
}

interface MasterData {
  material_types: Array<{ id: number; item_name: string; is_active: boolean }>;
  component_uoms: Array<{ id: number; item_name: string; is_active: boolean }>;
  packaging_materials: Array<{ id: number; item_name: string; is_active: boolean; item_name_new?: string; packaging_type_ids?: string }>;
  packaging_levels: Array<{ id: number; item_name: string; is_active: boolean }>;
  component_base_uoms: Array<{ id: number; item_name: string; is_active: boolean }>;
  component_packaging_type: Array<{ 
    id: number; 
    item_name: string; 
    item_order: number;
    component_packaging_material: number | null;
    item_name_new: string;
    min_weight_in_grams: string | null;
    max_weight_in_grams: string | null;
  }>;
}

const EditComponentModal: React.FC<EditComponentModalProps> = ({
  show,
  onClose,
  component,
  onSuccess
}) => {
  // State for collapsible sections
  const [showAdvancedComponentFields, setShowAdvancedComponentFields] = useState(false);
  const [showRecyclingComponentFields, setShowRecyclingComponentFields] = useState(false);

  // Component data state
  const [editComponentData, setEditComponentData] = useState<EditComponentData>({
    componentType: '',
    componentCode: '',
    componentDescription: '',
    componentCategory: '',
    componentQuantity: '',
    componentUnitOfMeasure: '',
    componentBaseQuantity: '',
    componentBaseUnitOfMeasure: '',
    wW: '',
    componentPackagingType: '',
    componentPackagingMaterial: '',
    componentUnitWeight: '',
    componentWeightUnitOfMeasure: '',
    percentPostConsumer: '',
    percentPostIndustrial: '',
    percentChemical: '',
    percentBioSourced: '',
    materialStructure: '',
    packagingColour: '',
    packagingLevel: '',
    componentDimensions: '',
    packagingEvidence: [],
    validityFrom: '',
    validityTo: ''
  });

  // Error state
  const [editComponentErrors, setEditComponentErrors] = useState<EditComponentErrors>({
    componentType: '',
    componentCode: '',
    componentDescription: '',
    componentCategory: '',
    componentQuantity: '',
    componentUnitOfMeasure: '',
    componentBaseQuantity: '',
    componentBaseUnitOfMeasure: '',
    wW: '',
    componentPackagingType: '',
    componentPackagingMaterial: '',
    componentUnitWeight: '',
    componentWeightUnitOfMeasure: '',
    percentPostConsumer: '',
    percentPostIndustrial: '',
    percentChemical: '',
    percentBioSourced: '',
    materialStructure: '',
    packagingColour: '',
    packagingLevel: '',
    componentDimensions: '',
    validityFrom: '',
    validityTo: '',
    percentageSum: ''
  });

  // Success and loading states
  const [editComponentSuccess, setEditComponentSuccess] = useState('');
  const [editComponentLoading, setEditComponentLoading] = useState(false);
  
  // Confirmation modal state
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);

  // Add state for category selection (same as Add Component modal)
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [categoryError, setCategoryError] = useState<string>('');
  
  // Add state for file upload and table (same as Add Component modal)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<Array<{id: string, categories: string[], categoryName?: string, files: File[]}>>([]);

  // Master data state
  const [masterData, setMasterData] = useState<MasterData | null>(null);
  const [masterDataLoading, setMasterDataLoading] = useState(false);

  // ===== DEPENDENT DROPDOWN LOGIC =====
  // Create a lookup map for text to ID conversion (for efficient filtering)
  const packagingTypeTextToIdMap = React.useMemo(() => {
    const map = new Map();
    masterData?.component_packaging_type?.forEach(type => {
      const text = type.item_name_new || type.item_name;
      map.set(text, type.id);
    });
    return map;
  }, [masterData?.component_packaging_type]);

  // Filter packaging materials based on selected packaging type
  const filteredPackagingMaterials = React.useMemo(() => {
    // If no packaging type selected, show ALL materials (default behavior)
    if (!editComponentData.componentPackagingType) {
      console.log('📦 No packaging type selected, showing all materials:', masterData?.packaging_materials?.length || 0);
      return masterData?.packaging_materials?.filter(item => item.is_active) || [];
    }
    
    // Convert text to ID using the lookup map
    const typeId = packagingTypeTextToIdMap.get(editComponentData.componentPackagingType);
    console.log('📦 Selected packaging type:', editComponentData.componentPackagingType, '-> ID:', typeId);
    
    // If no ID found, show ALL materials
    if (!typeId) {
      console.log('📦 No ID found for selected type, showing all materials');
      return masterData?.packaging_materials?.filter(item => item.is_active) || [];
    }
    
    // Filter materials where packaging_type_ids contains the selected type ID
    const filtered = masterData?.packaging_materials?.filter(material => {
      if (!material.is_active) return false;
      const typeIds = material.packaging_type_ids || '';
      const isMatch = typeIds.split(',').includes(typeId.toString());
      if (isMatch) {
        console.log('📦 Material match:', material.item_name_new || material.item_name, 'has type IDs:', typeIds);
      }
      return isMatch;
    }) || [];
    
    console.log('📦 Filtered materials count:', filtered.length, 'out of', masterData?.packaging_materials?.length || 0);
    return filtered;
  }, [editComponentData.componentPackagingType, packagingTypeTextToIdMap, masterData]);

  // Handle packaging type change - clear packaging material when type changes
  const handlePackagingTypeChange = (value: string) => {
    setEditComponentData({ 
      ...editComponentData, 
      componentPackagingType: value,
      componentPackagingMaterial: '' // Clear packaging material when type changes
    });
  };

  // ===== WEIGHT VALIDATION LOGIC =====
  // State for weight validation modal
  const [showWeightValidationModal, setShowWeightValidationModal] = useState(false);
  const [weightValidationData, setWeightValidationData] = useState<{
    weight: string;
    minWeight: string;
    maxWeight: string;
    packagingType: string;
    isBelowRange: boolean;
    isAboveRange: boolean;
    message: string;
  } | null>(null);

  // Validate weight against selected packaging type range
  const validateWeight = (weight: string, packagingTypeText: string) => {
    console.log('🔍 validateWeight called with:', { weight, packagingTypeText });
    console.log('🔍 masterData available:', !!masterData);
    console.log('🔍 component_packaging_type available:', !!masterData?.component_packaging_type);
    console.log('🔍 component_packaging_type length:', masterData?.component_packaging_type?.length);
    
    if (!weight || !packagingTypeText || !masterData?.component_packaging_type) {
      console.log('🔍 Early return - missing data:', { weight: !!weight, packagingTypeText: !!packagingTypeText, masterData: !!masterData });
      return { isValid: true, message: '' };
    }

    // Find packaging type by text value (item_name_new or item_name)
    const selectedPackagingType = masterData.component_packaging_type.find(
      type => (type.item_name_new || type.item_name) === packagingTypeText
    );

    console.log('🔍 Selected packaging type:', selectedPackagingType);
    console.log('🔍 Available packaging types:', masterData.component_packaging_type.map(t => ({ 
      id: t.id, 
      item_name: t.item_name, 
      item_name_new: t.item_name_new,
      min_weight: t.min_weight_in_grams,
      max_weight: t.max_weight_in_grams
    })));

    if (!selectedPackagingType?.min_weight_in_grams || !selectedPackagingType?.max_weight_in_grams) {
      console.log('No weight range defined for this packaging type');
      return { 
        isValid: false, 
        message: `No weight range defined for "${selectedPackagingType?.item_name_new || selectedPackagingType?.item_name}". Please select a different packaging type or contact administrator.`,
        isBelowRange: false,
        isAboveRange: false
      };
    }

    const enteredWeight = parseFloat(weight);
    const minWeight = parseFloat(selectedPackagingType.min_weight_in_grams);
    const maxWeight = parseFloat(selectedPackagingType.max_weight_in_grams);

    console.log('Weight comparison:', { enteredWeight, minWeight, maxWeight });

    if (isNaN(enteredWeight)) {
      console.log('Invalid weight entered');
      return { isValid: false, message: 'Please enter a valid weight' };
    }

    if (enteredWeight < minWeight) {
      console.log('Weight is below range');
      return { 
        isValid: false, 
        message: `Weight is below recommended range.`,
        isBelowRange: true,
        isAboveRange: false
      };
    }

    if (enteredWeight > maxWeight) {
      console.log('Weight is above range');
      return { 
        isValid: false, 
        message: ``,
        isBelowRange: false,
        isAboveRange: true
      };
    }

    console.log('Weight is within range - VALID');
    return { isValid: true, message: '' };
  };

  // Handle weight change with validation
  const handleWeightChange = (weight: string, packagingTypeText?: string) => {
    // Validate weight if weight is not empty
    if (weight && weight.trim() !== '') {
      const currentPackagingType = packagingTypeText || editComponentData.componentPackagingType;
      
      if (currentPackagingType) {
        // If packaging type is selected, validate against that specific type
        const validation = validateWeight(weight, currentPackagingType);
        
        if (!validation.isValid && validation.message) {
          const selectedType = masterData?.component_packaging_type?.find(
            type => (type.item_name_new || type.item_name) === currentPackagingType
          );
          
          setWeightValidationData({
            weight,
            minWeight: selectedType?.min_weight_in_grams || '',
            maxWeight: selectedType?.max_weight_in_grams || '',
            packagingType: selectedType?.item_name_new || selectedType?.item_name || '',
            isBelowRange: validation.isBelowRange || false,
            isAboveRange: validation.isAboveRange || false,
            message: validation.message
          });
          setShowWeightValidationModal(true);
        }
      } else {
        // If no packaging type selected, show message to select one first
        setWeightValidationData({
          weight,
          minWeight: '',
          maxWeight: '',
          packagingType: 'No packaging type selected',
          isBelowRange: false,
          isAboveRange: false,
          message: `Weight (${weight}g) entered. Please select a Component Packaging Type first to validate against the recommended range.`
        });
        setShowWeightValidationModal(true);
      }
    }
  };

  // Handle weight validation confirmation
  const handleWeightValidationConfirm = () => {
    setShowWeightValidationModal(false);
    setWeightValidationData(null);
    // User confirmed, continue with the current weight
  };

  // Handle weight validation cancel
  const handleWeightValidationCancel = () => {
    setShowWeightValidationModal(false);
    setWeightValidationData(null);
    // Reset weight to empty or previous valid value
    setEditComponentData({ ...editComponentData, componentUnitWeight: '' });
  };

  // Fetch master data on component mount
  useEffect(() => {
    const fetchMasterData = async () => {
      setMasterDataLoading(true);
      try {
        console.log('Fetching master data...');
        const data = await apiGet('/masterdata');
        console.log('Master data response:', data);
        if (data && data.success && data.data) {
          console.log('Setting master data:', data.data);
          console.log('Component packaging types count:', data.data.component_packaging_type?.length);
          console.log('Component packaging types data:', data.data.component_packaging_type);
          console.log('Master data keys:', Object.keys(data.data));
          console.log('Packaging levels count:', data.data.packaging_levels?.length);
          console.log('Component UOMs count:', data.data.component_uoms?.length);
          console.log('Packaging materials count:', data.data.packaging_materials?.length);
          
          // Transform the data to include proper weight range properties
          const transformedData = {
            ...data.data,
            component_packaging_type: data.data.component_packaging_type?.map((type: any) => ({
              id: type.id,
              item_name: type.item_name,
              item_order: type.item_order,
              component_packaging_material: type.component_packaging_material,
              item_name_new: type.item_name_new,
              min_weight_in_grams: type.min_weight_in_grams || null,
              max_weight_in_grams: type.max_weight_in_grams || null
            })) || []
          };
          
          setMasterData(transformedData);
        } else {
          console.log('API response not successful or no data:', data);
        }
      } catch (error) {
        console.error('Error fetching master data:', error);
      } finally {
        setMasterDataLoading(false);
      }
    };

    fetchMasterData();
  }, []);

  // Debug: Log when masterData changes
  useEffect(() => {
    console.log('MasterData state changed:', masterData);
    if (masterData) {
      console.log('Component packaging types available:', masterData.component_packaging_type?.length);
    }
  }, [masterData]);

  // Load component data when modal opens
  useEffect(() => {
    if (show && component) {
      console.log('🔍 EditModal - Loading component data:', component);
      console.log('🔍 EditModal - Component keys:', Object.keys(component || {}));
      console.log('🔍 EditModal - Component packaging type ID (single):', component.component_packaging_type_id);
      console.log('🔍 EditModal - Component packaging type ID (double):', component.component_packaging_type_id_id);
      console.log('🔍 EditModal - Component packaging type name:', component.component_packaging_type_id_name);
      console.log('🔍 EditModal - Master data available:', !!masterData);
      console.log('🔍 EditModal - Master data packaging types count:', masterData?.component_packaging_type?.length || 0);

      // Get the packaging type text - prefer display name if available, otherwise convert from ID
      let packagingTypeText = '';
      
      // First, try to use the display name directly if available
      if (component.component_packaging_type_id_name) {
        packagingTypeText = component.component_packaging_type_id_name;
        console.log('🔍 EditModal - Using display name directly:', packagingTypeText);
      } else {
        // Fallback: Get the packaging type ID and convert to text
        const packagingTypeId = component.component_packaging_type_id || component.component_packaging_type_id_id;
        console.log('🔍 EditModal - Using packaging type ID for conversion:', packagingTypeId);
        
        if (packagingTypeId && masterData?.component_packaging_type) {
          packagingTypeText = masterData.component_packaging_type.find(
            type => type.id.toString() === packagingTypeId?.toString()
          )?.item_name_new || masterData.component_packaging_type.find(
            type => type.id.toString() === packagingTypeId?.toString()
          )?.item_name || '';
        }
      }

      console.log('🔍 EditModal - Final packaging type text:', packagingTypeText);

      setEditComponentData({
        componentType: component.material_type_id?.toString() || '',
        componentCode: component.component_code || '',
        componentDescription: component.component_description || '',
        componentCategory: component.component_material_group || '',
        componentQuantity: component.component_quantity?.toString() || '',
        componentUnitOfMeasure: component.component_uom_id?.toString() || '',
        componentBaseQuantity: component.component_base_quantity?.toString() || '',
        componentBaseUnitOfMeasure: component.component_base_uom_id?.toString() || '',
        wW: component.percent_w_w?.toString() || '',
        componentPackagingType: packagingTypeText,
        componentPackagingMaterial: component.component_packaging_material || '',
        componentUnitWeight: component.component_unit_weight?.toString() || '',
        componentWeightUnitOfMeasure: component.weight_unit_measure_id?.toString() || '',
        percentPostConsumer: component.percent_mechanical_pcr_content?.toString() || '',
        percentPostIndustrial: component.percent_mechanical_pir_content?.toString() || '',
        percentChemical: component.percent_chemical_recycled_content?.toString() || '',
        percentBioSourced: component.percent_bio_sourced?.toString() || '',
        materialStructure: component.material_structure_multimaterials || '',
        packagingColour: component.component_packaging_color_opacity || '',
        packagingLevel: component.component_packaging_level_id?.toString() || '',
        componentDimensions: component.component_dimensions || '',
        packagingEvidence: [],
        validityFrom: component.component_valid_from ? component.component_valid_from.split('T')[0] : '',
        validityTo: component.component_valid_to ? component.component_valid_to.split('T')[0] : '',
        chPack: component.ch_pack || '',
        kpisEvidenceMapping: component.kpis_evidence_mapping || '',
        browseFiles: [],
        componentPackagingLevel: component.component_packaging_level_id || '',
        evidenceChemicalRecycled: []
      });
      
      // Load selected categories if they exist
      if (component.kpis_evidence_mapping) {
        try {
          const categories = JSON.parse(component.kpis_evidence_mapping);
          setSelectedCategories(Array.isArray(categories) ? categories : [categories]);
        } catch (e) {
          setSelectedCategories([]);
        }
      } else {
        setSelectedCategories([]);
      }
      
      // Load uploaded files if they exist (you may need to adjust this based on your data structure)
      if (component.uploaded_files) {
        try {
          setUploadedFiles(component.uploaded_files);
        } catch (e) {
          setUploadedFiles([]);
        }
      } else {
        setUploadedFiles([]);
      }
    }
  }, [show, component]);

  // Update packaging type when master data becomes available
  useEffect(() => {
    if (show && component && masterData) {
      console.log('🔍 EditModal - Updating packaging type with master data');
      console.log('🔍 EditModal - Component packaging type name:', component.component_packaging_type_id_name);
      
      // Get the packaging type text - prefer display name if available, otherwise convert from ID
      let packagingTypeText = '';
      
      // First, try to use the display name directly if available
      if (component.component_packaging_type_id_name) {
        packagingTypeText = component.component_packaging_type_id_name;
        console.log('🔍 EditModal - Using display name directly:', packagingTypeText);
      } else {
        // Fallback: Get the packaging type ID and convert to text
        const packagingTypeId = component.component_packaging_type_id || component.component_packaging_type_id_id;
        console.log('🔍 EditModal - Using packaging type ID for conversion:', packagingTypeId);
        
        if (packagingTypeId) {
          console.log('🔍 EditModal - Master data packaging types:', masterData.component_packaging_type?.map(t => ({ 
            id: t.id, 
            item_name: t.item_name, 
            item_name_new: t.item_name_new 
          })));
          
          packagingTypeText = masterData.component_packaging_type?.find(
            type => type.id.toString() === packagingTypeId?.toString()
          )?.item_name_new || masterData.component_packaging_type?.find(
            type => type.id.toString() === packagingTypeId?.toString()
          )?.item_name || '';
        }
      }

      console.log('🔍 EditModal - Updated packaging type text:', packagingTypeText);

      if (packagingTypeText) {
        setEditComponentData(prev => ({
          ...prev,
          componentPackagingType: packagingTypeText
        }));
      } else {
        console.warn('🔍 EditModal - No packaging type text found');
      }
    }
  }, [show, component, masterData]);

  // Reset states when modal closes
  useEffect(() => {
    if (!show) {
      setEditComponentData({
        componentType: '',
        componentCode: '',
        componentDescription: '',
        componentCategory: '',
        componentQuantity: '',
        componentUnitOfMeasure: '',
        componentBaseQuantity: '',
        componentBaseUnitOfMeasure: '',
        wW: '',
        componentPackagingType: '',
        componentPackagingMaterial: '',
        componentUnitWeight: '',
        componentWeightUnitOfMeasure: '',
        percentPostConsumer: '',
        percentPostIndustrial: '',
        percentChemical: '',
        percentBioSourced: '',
        materialStructure: '',
        packagingColour: '',
        packagingLevel: '',
        componentDimensions: '',
        packagingEvidence: [],
        validityFrom: '',
        validityTo: '',
        chPack: '',
        kpisEvidenceMapping: '',
        browseFiles: [],
        componentPackagingLevel: '',
        evidenceChemicalRecycled: []
      });
      setEditComponentErrors({
        componentType: '',
        componentCode: '',
        componentDescription: '',
        componentCategory: '',
        componentQuantity: '',
        componentUnitOfMeasure: '',
        componentBaseQuantity: '',
        componentBaseUnitOfMeasure: '',
        wW: '',
        componentPackagingType: '',
        componentPackagingMaterial: '',
        componentUnitWeight: '',
        componentWeightUnitOfMeasure: '',
        percentPostConsumer: '',
        percentPostIndustrial: '',
        percentChemical: '',
        percentBioSourced: '',
        materialStructure: '',
        packagingColour: '',
        packagingLevel: '',
        componentDimensions: '',
        validityFrom: '',
        validityTo: '',
        percentageSum: ''
      });
      setEditComponentSuccess('');
      setEditComponentLoading(false);
      setSelectedCategories([]);
      setCategoryError('');
      setSelectedFiles([]);
      setUploadedFiles([]);
    }
  }, [show]);

  // Handle save with action type
  const handleEditComponentSave = async (action: 'UPDATE' | 'REPLACE') => {
    console.log('handleEditComponentSave called with action:', action);
    console.log('Current component data:', editComponentData);
    console.log('Component prop:', component);
    console.log('Component mapping_id:', component?.mapping_id);
    
    // Validation logic here - Updated for percentageSum
    const errors: EditComponentErrors = {
      componentType: '',
      componentCode: '',
      componentDescription: '',
      componentCategory: '',
      componentQuantity: '',
      componentUnitOfMeasure: '',
      componentBaseQuantity: '',
      componentBaseUnitOfMeasure: '',
      wW: '',
      componentPackagingType: '',
      componentPackagingMaterial: '',
      componentUnitWeight: '',
      componentWeightUnitOfMeasure: '',
      percentPostConsumer: '',
      percentPostIndustrial: '',
      percentChemical: '',
      percentBioSourced: '',
      materialStructure: '',
      packagingColour: '',
      packagingLevel: '',
      componentDimensions: '',
      validityFrom: '',
      validityTo: '',
      percentageSum: ''
    };

    let hasErrors = false;

    if (!editComponentData.validityFrom) {
      errors.validityFrom = 'Component validity date - From is required';
      hasErrors = true;
    }

    if (!editComponentData.validityTo) {
      errors.validityTo = 'Component validity date - To is required';
      hasErrors = true;
    }

    // Component Quantity validation
    if (!editComponentData.componentQuantity || editComponentData.componentQuantity.trim() === '') {
      errors.componentQuantity = 'Please enter Component Quantity';
      hasErrors = true;
    }

    // Component Unit of Measure validation
    if (!editComponentData.componentUnitOfMeasure || editComponentData.componentUnitOfMeasure.trim() === '') {
      errors.componentUnitOfMeasure = 'Please select Component Unit of Measure';
      hasErrors = true;
    }

    // Component Base Quantity validation
    if (!editComponentData.componentBaseQuantity || editComponentData.componentBaseQuantity.trim() === '') {
      errors.componentBaseQuantity = 'Please enter Component Base Quantity';
      hasErrors = true;
    }

    // Component Base Unit of Measure validation
    if (!editComponentData.componentBaseUnitOfMeasure || editComponentData.componentBaseUnitOfMeasure.trim() === '') {
      errors.componentBaseUnitOfMeasure = 'Please select Component Base Unit of Measure';
      hasErrors = true;
    }

    // Component Packaging Type validation
    if (!editComponentData.componentPackagingType || editComponentData.componentPackagingType.trim() === '') {
      errors.componentPackagingType = 'Please select Component Packaging Type';
      hasErrors = true;
    }

    // Component Packaging Material validation
    if (!editComponentData.componentPackagingMaterial || editComponentData.componentPackagingMaterial.trim() === '') {
      errors.componentPackagingMaterial = 'Please select Component Packaging Material';
      hasErrors = true;
    }

    // Component Unit Weight validation
    if (!editComponentData.componentUnitWeight || editComponentData.componentUnitWeight.trim() === '') {
      errors.componentUnitWeight = 'Please enter Component Unit Weight';
      hasErrors = true;
    }

    // Component Weight Unit of Measure validation
    if (!editComponentData.componentWeightUnitOfMeasure || editComponentData.componentWeightUnitOfMeasure.trim() === '') {
      errors.componentWeightUnitOfMeasure = 'Please select Component Weight Unit of Measure';
      hasErrors = true;
    }

    // % Mechanical Post-Consumer Recycled Content validation
    if (!editComponentData.percentPostConsumer || editComponentData.percentPostConsumer.trim() === '') {
      errors.percentPostConsumer = 'Please enter % Mechanical Post-Consumer Recycled Content';
      hasErrors = true;
    }

    // % Mechanical Post-Industrial Recycled Content validation
    if (!editComponentData.percentPostIndustrial || editComponentData.percentPostIndustrial.trim() === '') {
      errors.percentPostIndustrial = 'Please enter % Mechanical Post-Industrial Recycled Content';
      hasErrors = true;
    }

    // % Chemical Recycled Content validation
    if (!editComponentData.percentChemical || editComponentData.percentChemical.trim() === '') {
      errors.percentChemical = 'Please enter % Chemical Recycled Content';
      hasErrors = true;
    }

    // % Bio-sourced validation
    if (!editComponentData.percentBioSourced || editComponentData.percentBioSourced.trim() === '') {
      errors.percentBioSourced = 'Please enter % Bio-sourced value';
      hasErrors = true;
    }

    // Validation: Sum of all recycling content fields cannot exceed 100%
    const percentPostConsumer = parseFloat(editComponentData.percentPostConsumer) || 0;
    const percentPostIndustrial = parseFloat(editComponentData.percentPostIndustrial) || 0;
    const percentChemical = parseFloat(editComponentData.percentChemical) || 0;
    const percentBioSourced = parseFloat(editComponentData.percentBioSourced) || 0;
    
    const totalRecyclingContent = percentPostConsumer + percentPostIndustrial + percentChemical + percentBioSourced;
    
    if (totalRecyclingContent > 100) {
      const errorMessage = `Total recycling content cannot exceed 100%. Current total: ${totalRecyclingContent.toFixed(2)}%`;
      errors.percentPostConsumer = errorMessage;
      errors.percentPostIndustrial = errorMessage;
      errors.percentChemical = errorMessage;
      errors.percentBioSourced = errorMessage;
      hasErrors = true;
    }

    // Validation: Prevent negative values for numeric fields
    // Component Base Quantity validation
    if (editComponentData.componentBaseQuantity && editComponentData.componentBaseQuantity.trim() !== '') {
      const baseQuantityValue = parseFloat(editComponentData.componentBaseQuantity);
      if (isNaN(baseQuantityValue)) {
        errors.componentBaseQuantity = 'Please enter a valid number for Component Base Quantity';
        hasErrors = true;
      } else if (baseQuantityValue < 0) {
        errors.componentBaseQuantity = 'Component Base Quantity cannot be less than 0';
        hasErrors = true;
      }
    }

    // Component Unit Weight validation
    if (editComponentData.componentUnitWeight && editComponentData.componentUnitWeight.trim() !== '') {
      const unitWeightValue = parseFloat(editComponentData.componentUnitWeight);
      if (isNaN(unitWeightValue)) {
        errors.componentUnitWeight = 'Please enter a valid number for Component Unit Weight';
        hasErrors = true;
      } else if (unitWeightValue < 0) {
        errors.componentUnitWeight = 'Component Unit Weight cannot be less than 0';
        hasErrors = true;
      }
    }

    // %w/w validation
    if (editComponentData.wW && editComponentData.wW.trim() !== '') {
      const wWValue = parseFloat(editComponentData.wW);
      if (isNaN(wWValue)) {
        errors.wW = 'Please enter a valid number for %w/w';
        hasErrors = true;
      } else if (wWValue < 0) {
        errors.wW = '%w/w cannot be less than 0';
        hasErrors = true;
      } else if (wWValue > 100) {
        errors.wW = '%w/w cannot be greater than 100';
        hasErrors = true;
      }
    }

    if (hasErrors) {
      console.log('Validation errors found:', errors);
      setEditComponentErrors(errors);
      
      // Auto-expand collapsed sections that contain validation errors
      const errorFields = Object.keys(errors).filter(key => errors[key as keyof EditComponentErrors] !== '');
      
      // Check if any advanced fields have errors
      const advancedFields = ['componentPackagingType', 'componentPackagingMaterial', 'componentUnitWeight', 'componentWeightUnitOfMeasure', 'percentPostConsumer', 'percentPostIndustrial', 'percentChemical', 'percentBioSourced', 'materialStructure', 'packagingColour', 'packagingLevel', 'componentDimensions', 'validityFrom', 'validityTo'];
      const hasAdvancedErrors = advancedFields.some(field => errors[field as keyof EditComponentErrors] !== '');
      
      if (hasAdvancedErrors && !showAdvancedComponentFields) {
        setShowAdvancedComponentFields(true);
      }
      
      // Check if any recycling fields have errors
      const recyclingFields = ['percentPostConsumer', 'percentPostIndustrial', 'percentChemical', 'percentBioSourced'];
      const hasRecyclingErrors = recyclingFields.some(field => errors[field as keyof EditComponentErrors] !== '');
      
      if (hasRecyclingErrors && !showRecyclingComponentFields) {
        setShowRecyclingComponentFields(true);
      }
      
      // Scroll to first error field after a short delay to allow expansion
      setTimeout(() => {
        const firstErrorField = errorFields[0];
        if (firstErrorField) {
          const errorElement = document.querySelector(`[data-field="${firstErrorField}"]`) || 
                              document.querySelector(`[name="${firstErrorField}"]`) ||
                              document.querySelector(`input[value="${editComponentData[firstErrorField as keyof EditComponentData]}"]`);
          if (errorElement) {
            errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            if (errorElement instanceof HTMLElement) {
              errorElement.focus();
            }
          }
        }
      }, 300);
      
      return;
    }

    console.log('Validation passed, proceeding with API call');

    // Check if component has valid mapping_id
    if (!component?.mapping_id) {
      console.error('Component mapping_id is missing:', component);
      setEditComponentErrors({ ...editComponentErrors, general: 'Component ID is missing. Cannot update component.' });
      return;
    }

    setEditComponentLoading(true);

         try {
       console.log('Creating FormData for API call...');
       console.log('Component mapping_id:', component.mapping_id);
       console.log('Action type:', action);
       
       // Create FormData for file uploads
       const formData = new FormData();
       
               // Add action type (UPDATE or REPLACE)
        formData.append('action', action);
       
       // Add mapping_id for component identification
       if (component?.mapping_id) {
         formData.append('mapping_id', component.mapping_id.toString());
         formData.append('component_mapping_id', component.mapping_id.toString());
       }
       
       // Add cm_code from component prop
       console.log('🔍 Component object keys:', Object.keys(component || {}));
       console.log('🔍 Component cm_code:', component?.cm_code);
       console.log('🔍 Component sku_code:', component?.sku_code);
       console.log('🔍 Component mapping_id:', component?.mapping_id);
       
       if (component?.cm_code) {
         formData.append('cm_code', component.cm_code);
         formData.append('cmCode', component.cm_code);
         formData.append('cm_code_audit', component.cm_code); // Try audit-specific field name
         formData.append('audit_cm_code', component.cm_code); // Try another variation
         console.log('✅ Added cm_code to FormData:', component.cm_code);
       } else {
         console.error('❌ cm_code is missing from component object');
         console.error('❌ Full component object:', component);
         
         // Try to get cm_code from other possible sources
         if (component?.sku_code) {
           console.log('⚠️ cm_code not found, but sku_code is available:', component.sku_code);
         }
         
         // Add a fallback cm_code - you might need to adjust this based on your requirements
         const fallbackCmCode = 'UNKNOWN_CM_CODE';
         formData.append('cm_code', fallbackCmCode);
         formData.append('cmCode', fallbackCmCode);
         formData.append('cm_code_audit', fallbackCmCode);
         formData.append('audit_cm_code', fallbackCmCode);
         console.log('⚠️ Using fallback cm_code:', fallbackCmCode);
       }
       
       // Add all form fields
       formData.append('componentType', editComponentData.componentType);
       formData.append('componentCode', editComponentData.componentCode);
       formData.append('componentDescription', editComponentData.componentDescription);
       formData.append('componentCategory', editComponentData.componentCategory);
       formData.append('componentQuantity', editComponentData.componentQuantity);
       formData.append('componentUnitOfMeasure', editComponentData.componentUnitOfMeasure);
       formData.append('componentBaseQuantity', editComponentData.componentBaseQuantity);
       formData.append('componentBaseUnitOfMeasure', editComponentData.componentBaseUnitOfMeasure);
       formData.append('wW', editComponentData.wW);
       formData.append('componentPackagingType', editComponentData.componentPackagingType);
       formData.append('componentPackagingMaterial', editComponentData.componentPackagingMaterial);
       formData.append('componentUnitWeight', editComponentData.componentUnitWeight);
       formData.append('componentWeightUnitOfMeasure', editComponentData.componentWeightUnitOfMeasure);
       formData.append('percentPostConsumer', editComponentData.percentPostConsumer);
       formData.append('percentPostIndustrial', editComponentData.percentPostIndustrial);
       formData.append('percentChemical', editComponentData.percentChemical);
       formData.append('percentBioSourced', editComponentData.percentBioSourced);
       formData.append('materialStructure', editComponentData.materialStructure);
       formData.append('packagingColour', editComponentData.packagingColour);
       formData.append('packagingLevel', editComponentData.packagingLevel);
       formData.append('componentDimensions', editComponentData.componentDimensions);
       formData.append('validityFrom', editComponentData.validityFrom);
       formData.append('validityTo', editComponentData.validityTo);
       formData.append('chPack', editComponentData.chPack || '');
       formData.append('kpisEvidenceMapping', editComponentData.kpisEvidenceMapping || '');
       
       // Add files
       if (editComponentData.packagingEvidence && editComponentData.packagingEvidence.length > 0) {
         editComponentData.packagingEvidence.forEach(file => {
           formData.append('packagingEvidence', file);
         });
       }
       
       if (editComponentData.evidenceChemicalRecycled && editComponentData.evidenceChemicalRecycled.length > 0) {
         editComponentData.evidenceChemicalRecycled.forEach(file => {
           formData.append('evidenceChemicalRecycled', file);
         });
       }
       
               // Log FormData contents for debugging
       console.log('FormData contents:');
       const formDataEntries = Array.from(formData.entries());
       formDataEntries.forEach(([key, value]) => {
         console.log(`${key}:`, value);
       });
       
       // Check specifically for cm_code
       const cmCodeEntry = formDataEntries.find(([key]) => key === 'cm_code');
       console.log('🔍 cm_code entry in FormData:', cmCodeEntry);
       console.log('🔍 All FormData keys:', formDataEntries.map(([key]) => key));
       
       console.log('Making API call to:', `/component-details/${component.mapping_id}`);
       
       // Always use POST with FormData for consistency
        const updateResult = await apiPostFormData(`/component-details/${component.mapping_id}`, formData);
        
        console.log('API call result:', updateResult);
      
      if (updateResult && updateResult.ok) {
        console.log('API call successful, parsing response...');
        const resultData = await updateResult.json();
        console.log('API response data:', resultData);
        
                 if (resultData.success) {
          console.log('Component updated successfully!');
          setEditComponentSuccess('Component updated successfully!');
           
           setTimeout(() => {
             onSuccess();
             onClose();
           }, 1500);
         } else {
          console.log('API returned success: false, message:', resultData.message);
          setEditComponentErrors({ ...editComponentErrors, general: resultData.message || 'Failed to update component' });
        }
      } else {
        console.log('API call failed, status:', updateResult?.status, 'statusText:', updateResult?.statusText);
        setEditComponentErrors({ ...editComponentErrors, general: 'Failed to update component' });
      }
    } catch (error) {
      console.error('Error updating component:', error);
      setEditComponentErrors({ ...editComponentErrors, general: 'An error occurred while updating the component' });
    } finally {
      setEditComponentLoading(false);
    }
  };

  if (!show) return null;

  return (
    <div className="modal fade show" style={{ display: 'block', background: 'rgba(0,0,0,0.6)' }} tabIndex={-1}>
      <div className="modal-dialog modal-xl" style={{ maxWidth: '90vw', margin: '2vh auto' }}>
        <div className="modal-content" style={{ 
          borderRadius: '12px', 
          border: 'none',
          boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
          maxHeight: '90vh'
        }}>
          {/* Modal Header */}
          <div className="modal-header" style={{ 
            backgroundColor: '#30ea03', 
            color: '#000', 
            borderBottom: '2px solid #000', 
            alignItems: 'center',
            padding: '20px 30px',
            borderRadius: '12px 12px 0 0'
          }}>
            <div style={{ flex: 1, marginLeft: '20px' }}>
              <h5 className="modal-title" style={{ 
                color: '#000', 
                fontWeight: 700, 
                fontSize: '20px',
                margin: 0,
                marginBottom: '5px',
              }}>
                <i className="ri-edit-line" style={{ marginRight: '10px', fontSize: '22px' }} />
                Edit Component Details
              </h5>
              {component && component.component_id && (
                <div style={{
                  fontSize: '14px',
                  color: '#666',
                  fontWeight: 500,
                  display: 'none', // Hidden as requested
                  alignItems: 'center',
                  gap: '8px'
                }}>
                  <i className="ri-hashtag" style={{ fontSize: '16px' }} />
                  Component ID: {component.component_id}
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              style={{ 
                background: 'none', 
                border: 'none', 
                color: '#000', 
                fontSize: 28, 
                fontWeight: 900, 
                lineHeight: 1, 
                cursor: 'pointer', 
                marginLeft: 8,
                padding: '0',
                width: '32px',
                height: '32px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '50%'
              }}
            >
              &times;
            </button>
          </div>

          {/* Modal Body */}
          <div className="modal-body" style={{ 
            background: '#fff',
            padding: '30px',
            maxHeight: 'calc(90vh - 120px)',
            overflowY: 'auto'
          }}>
            {/* Success/Error Messages */}
            {editComponentSuccess && (
              <div style={{
                padding: '12px 16px',
                marginBottom: '20px',
                backgroundColor: '#d4edda',
                border: '1px solid #c3e6cb',
                borderRadius: '6px',
                color: '#155724',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <i className="ri-check-line" style={{ fontSize: '16px' }} />
                {editComponentSuccess}
              </div>
            )}

            {editComponentErrors.general && (
              <div style={{
                padding: '12px 16px',
                marginBottom: '20px',
                backgroundColor: '#f8d7da',
                border: '1px solid #f5c6cb',
                borderRadius: '6px',
                color: '#721c24',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <i className="ri-error-warning-line" style={{ fontSize: '16px' }} />
                {editComponentErrors.general}
              </div>
            )}

            {/* Basic Component Information Section */}
            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                padding: '20px',
                border: '1px solid #dee2e6',
                borderRadius: '8px',
                backgroundColor: '#fff'
              }}>
                <div className="row">
                  {/* Component Code - FIRST FIELD */}
                  <div className="col-md-6">
                    <label>
                      Component Code
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'help', 
                          color: '#666',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Component Code (Read-only field)"
                      >
                        <i className="ri-lock-line"></i>
                      </span>
                    </label>
                    <input
                      type="text"
                      value={editComponentData.componentCode}
                      disabled
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ccc',
                        borderRadius: '4px',
                        fontSize: '14px',
                        cursor: 'not-allowed',
                        backgroundColor: '#f5f5f5',
                        color: '#666'
                      }}
                    />
                  </div>

                  {/* Component Type */}
                  <div className="col-md-6">
                    <label>
                      Component Type
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'help', 
                          color: '#666',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Component Type (Read-only field)"
                      >
                        <i className="ri-lock-line"></i>
                      </span>
                    </label>
                    <select
                      value={editComponentData.componentType}
                      disabled
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ccc',
                        borderRadius: '4px',
                        fontSize: '14px',
                        appearance: 'none',
                        backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 8px center',
                        backgroundSize: '16px',
                        paddingRight: '32px',
                        cursor: 'not-allowed',
                        backgroundColor: '#f5f5f5',
                        color: '#666',
                        transition: 'all 0.2s ease'
                      }}
                    >
                      <option value="">Select Component Type</option>
                      {masterData?.material_types?.filter(item => item.is_active).map((item) => (
                        <option key={item.id} value={item.item_name}>
                          {item.item_name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="row" style={{ marginTop: '20px' }}>
                  {/* Component Description */}
                  <div className="col-md-6">
                    <label>
                      Component Description <span style={{ color: 'red' }}>*</span>
                    </label>
                    <input
                      type="text"
                      value={editComponentData.componentDescription}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentDescription: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                    {editComponentErrors.componentDescription && (
                      <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                        {editComponentErrors.componentDescription}
                      </div>
                    )}
                  </div>

                  {/* Component Category */}
                  <div className="col-md-6">
                    <label>Component Category</label>
                    <input
                      type="text"
                      value={editComponentData.componentCategory}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentCategory: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                </div>

                <div className="row" style={{ marginTop: '20px' }}>
                  {/* Component Quantity */}
                  <div className="col-md-6">
                    <label>
                      Component Quantity <span style={{ color: 'red' }}>*</span>
                    </label>
                    <input
                      type="number"
                      value={editComponentData.componentQuantity}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentQuantity: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                      placeholder="Enter component quantity"
                    />
                    {editComponentErrors.componentQuantity && (
                      <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                        {editComponentErrors.componentQuantity}
                      </div>
                    )}
                  </div>

                  {/* %w/w */}
                  <div className="col-md-6">
                    <label>
                      %w/w
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={editComponentData.wW}
                      onChange={(e) => setEditComponentData({ ...editComponentData, wW: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                      placeholder="Enter %w/w value"
                    />
                    {editComponentErrors.wW && (
                      <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                        {editComponentErrors.wW}
                      </div>
                    )}
                  </div>
                </div>

                <div className="row" style={{ marginTop: '20px' }}>
                  {/* Component packaging level - MOVED TO FIRST SECTION */}
                  <div className="col-md-6">
                    <label>
                      Component packaging level
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Select packaging level"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <select
                      value={editComponentData.componentPackagingLevel || ''}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentPackagingLevel: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px',
                        appearance: 'none',
                        backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 8px center',
                        backgroundSize: '16px',
                        paddingRight: '32px',
                        cursor: 'pointer',
                        backgroundColor: '#fff',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                        e.currentTarget.style.outline = 'none';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <option value="">Select Packaging Level</option>
                      {(() => {
                        console.log('Master data for packaging levels:', masterData?.packaging_levels);
                        return null;
                      })()}
                      {masterDataLoading ? (
                        <option value="" disabled>Loading...</option>
                      ) : masterData?.packaging_levels && masterData.packaging_levels.length > 0 ? (
                        masterData.packaging_levels.filter(item => item.is_active).map((item) => (
                          <option key={item.id} value={item.item_name}>
                            {item.item_name}
                          </option>
                        ))
                      ) : (
                        <option value="" disabled>No data available</option>
                      )}
                    </select>
                  </div>

                  {/* Component dimensions (3D - LxWxH, 2D - LxW) - MOVED TO FIRST SECTION */}
                  <div className="col-md-6">
                    <label>
                      Component dimensions (3D - LxWxH, 2D - LxW)
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Enter component dimensions"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <input
                      type="text"
                      value={editComponentData.componentDimensions || ''}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentDimensions: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                      placeholder="Enter dimensions (e.g., 10x5x3 cm)"
                    />
                  </div>
                </div>
{/* 
                <div className="row" style={{ marginTop: '20px' }}>
                
                  <div className="col-md-6">
                    <label>
                      Evidence of % of chemical recycled or bio-source
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Upload evidence files"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <input
                      type="file"
                      multiple
                      onChange={(e) => {
                        const files = Array.from(e.target.files || []);
                        setEditComponentData({ ...editComponentData, evidenceChemicalRecycled: files });
                      }}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                    {editComponentData.evidenceChemicalRecycled && editComponentData.evidenceChemicalRecycled.length > 0 && (
                      <div style={{ marginTop: '8px', fontSize: '12px', color: '#666' }}>
                        Selected files: {editComponentData.evidenceChemicalRecycled.map(file => file.name).join(', ')}
                      </div>
                    )}
                  </div>
                </div> */}

                <div className="row" style={{ marginTop: '20px' }}>
                 
                  <div className="col-md-6">
                    <label>
                      Component Unit of Measure <span style={{ color: 'red' }}>*</span>
                    </label>
                    <select
                      value={editComponentData.componentUnitOfMeasure}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentUnitOfMeasure: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px',
                        appearance: 'none',
                        backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 8px center',
                        backgroundSize: '16px',
                        paddingRight: '32px',
                        cursor: 'pointer',
                        backgroundColor: '#fff',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                        e.currentTarget.style.outline = 'none';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <option value="">Select UoM</option>
                      {masterData?.component_uoms?.filter(item => item.is_active).map((item) => (
                        <option key={item.id} value={item.item_name}>
                          {item.item_name}
                        </option>
                      ))}
                    </select>
                    {editComponentErrors.componentUnitOfMeasure && (
                      <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                        {editComponentErrors.componentUnitOfMeasure}
                      </div>
                    )}
                  </div>

                 
                  <div className="col-md-6">
                    <label>Component Base Quantity <span style={{ color: 'red' }}>*</span></label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={editComponentData.componentBaseQuantity}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentBaseQuantity: e.target.value })}
                      className={`form-control${editComponentErrors.componentBaseQuantity ? ' is-invalid' : ''}`}
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                </div>

                <div className="row" style={{ marginTop: '20px' }}>
                  {/* Component Base Unit of Measure */}
                  <div className="col-md-6">
                    <label>Component Base Unit of Measure <span style={{ color: 'red' }}>*</span></label>
                    <select
                      value={editComponentData.componentBaseUnitOfMeasure}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentBaseUnitOfMeasure: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px',
                        appearance: 'none',
                        backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 8px center',
                        backgroundSize: '16px',
                        paddingRight: '32px',
                        cursor: 'pointer',
                        backgroundColor: '#fff',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                        e.currentTarget.style.outline = 'none';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <option value="">Select Base UoM</option>
                      {masterData?.component_base_uoms?.filter(item => item.is_active).map((item) => (
                        <option key={item.id} value={item.item_name}>
                          {item.item_name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Advanced Component Information - Second Collapsible Section */}
            <div style={{ marginBottom: '24px' }}>
              <div
                style={{
                  backgroundColor: '#000',
                  padding: '15px 20px',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  borderRadius: '8px',
                  transition: 'background-color 0.2s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#333'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#000'}
                onClick={() => setShowAdvancedComponentFields(!showAdvancedComponentFields)}
              >
                <div style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '12px',
                  color: '#fff',
                  fontWeight: '500',
                  fontSize: '14px'
                }}>
                  <div style={{
                    width: '20px',
                    height: '20px',
                    borderRadius: '50%',
                    border: '1px solid #fff',
                    backgroundColor: 'transparent',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '12px',
                    color: '#fff'
                  }}>
                    {showAdvancedComponentFields ? '−' : '+'}
                  </div>
                  Advanced Component Information
                  {(() => {
                    const advancedFields = ['componentPackagingType', 'componentPackagingMaterial', 'componentUnitWeight', 'componentWeightUnitOfMeasure', 'percentPostConsumer', 'percentPostIndustrial', 'percentChemical', 'percentBioSourced', 'materialStructure', 'packagingColour', 'packagingLevel', 'componentDimensions', 'validityFrom', 'validityTo'];
                    const hasAdvancedErrors = advancedFields.some(field => editComponentErrors[field as keyof EditComponentErrors] !== '');
                    return hasAdvancedErrors ? (
                      <span style={{ 
                        color: '#dc3545', 
                        fontSize: '12px', 
                        marginLeft: '8px',
                        fontWeight: 'bold'
                      }}>
                        ⚠️ Has Errors
                      </span>
                    ) : null;
                  })()}
                </div>
              </div>

              {showAdvancedComponentFields && (
                <div style={{ 
                  padding: '20px',
                  border: '1px solid #dee2e6',
                  borderTop: 'none',
                  borderRadius: '0 0 8px 8px',
                  backgroundColor: '#fff'
                }}>
                  <div className="row">
                    {/* Component Packaging Type */}
                    <div className="col-md-6">
                      <label>Component Packaging Type <span style={{ color: 'red' }}>*</span></label>
                      <select
                        value={editComponentData.componentPackagingType}
                        onChange={(e) => handlePackagingTypeChange(e.target.value)}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px',
                          appearance: 'none',
                          backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                          backgroundRepeat: 'no-repeat',
                          backgroundPosition: 'right 8px center',
                          backgroundSize: '16px',
                          paddingRight: '32px',
                          cursor: 'pointer',
                          backgroundColor: '#fff',
                          transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = '#30ea03';
                          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = '#ddd';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = '#30ea03';
                          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                          e.currentTarget.style.outline = 'none';
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = '#ddd';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <option value="">Select Packaging Type</option>
                        {(() => {
                          const packagingTypeId = component?.component_packaging_type_id || component?.component_packaging_type_id_id;
                          console.log('🔍 Component Packaging Type Dropdown Debug:');
                          console.log('  - Master data available:', !!masterData);
                          console.log('  - Master data packaging types:', masterData?.component_packaging_type?.length || 0);
                          console.log('  - Current value:', editComponentData.componentPackagingType);
                          console.log('  - Component packaging type ID (single):', component?.component_packaging_type_id);
                          console.log('  - Component packaging type ID (double):', component?.component_packaging_type_id_id);
                          console.log('  - Component packaging type name:', component?.component_packaging_type_id_name);
                          console.log('  - Using packaging type ID:', packagingTypeId);
                          console.log('  - Available options:', masterData?.component_packaging_type?.map(t => ({ 
                            id: t.id, 
                            item_name: t.item_name, 
                            item_name_new: t.item_name_new 
                          })));
                          return null;
                        })()}
                        {masterDataLoading ? (
                          <option value="" disabled>Loading...</option>
                        ) : masterData?.component_packaging_type && masterData.component_packaging_type.length > 0 ? (
                          masterData.component_packaging_type.map((item) => (
                            <option key={item.id} value={item.item_name_new}>
                              {item.item_name_new}
                            </option>
                          ))
                        ) : (
                          <option value="" disabled>No data available</option>
                        )}
                      </select>
                    </div>

                    {/* Component Packaging Material */}
                    <div className="col-md-6">
                      <label>Component Packaging Material <span style={{ color: 'red' }}>*</span></label>
                      <select
                        value={editComponentData.componentPackagingMaterial}
                        onChange={(e) => setEditComponentData({ ...editComponentData, componentPackagingMaterial: e.target.value })}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px',
                          appearance: 'none',
                          backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                          backgroundRepeat: 'no-repeat',
                          backgroundPosition: 'right 8px center',
                          backgroundSize: '16px',
                          paddingRight: '32px',
                          cursor: 'pointer',
                          backgroundColor: '#fff',
                          transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = '#30ea03';
                          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = '#ddd';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = '#30ea03';
                          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                          e.currentTarget.style.outline = 'none';
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = '#ddd';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <option value="">Select Packaging Material</option>
                        {filteredPackagingMaterials.length > 0 ? (
                          filteredPackagingMaterials.map((item) => (
                            <option key={item.id} value={item.item_name}>
                              {item.item_name}
                            </option>
                          ))
                        ) : (
                          <option value="" disabled>
                            {editComponentData.componentPackagingType 
                              ? 'No materials available for selected packaging type' 
                              : 'Loading packaging materials...'
                            }
                          </option>
                        )}
                      </select>
                    </div>
                  </div>

                  <div className="row" style={{ marginTop: '20px' }}>
                    {/* Component Unit Weight */}
                    <div className="col-md-6">
                      <label>Component Unit Weight <span style={{ color: 'red' }}>*</span></label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={editComponentData.componentUnitWeight}
                        onChange={(e) => setEditComponentData({...editComponentData, componentUnitWeight: e.target.value})}
                        onBlur={(e) => {
                          const weight = e.target.value;
                          console.log('🔍 EditModal - Weight onBlur triggered:', weight);
                          console.log('🔍 EditModal - Current packaging type:', editComponentData.componentPackagingType);
                          console.log('🔍 EditModal - Master data available:', !!masterData);
                          console.log('🔍 EditModal - Component packaging types available:', !!masterData?.component_packaging_type);
                          
                          // Update state
                          setEditComponentData({...editComponentData, componentUnitWeight: weight});
                          
                          // Always validate if weight is not empty
                          if (weight && weight.trim() !== '') {
                            console.log('🔍 EditModal - Validating weight:', weight);
                            
                            if (editComponentData.componentPackagingType) {
                              console.log('🔍 EditModal - Packaging type selected, validating against range');
                              // If packaging type is selected, validate against that specific type
                              const validation = validateWeight(weight, editComponentData.componentPackagingType);
                              console.log('🔍 EditModal - Validation result:', validation);
                              
                              if (!validation.isValid && validation.message) {
                                console.log('EditModal - Showing validation modal');
                                const selectedType = masterData?.component_packaging_type?.find(
                                  type => (type.item_name_new || type.item_name) === editComponentData.componentPackagingType
                                );
                                
                                setWeightValidationData({
                                  weight,
                                  minWeight: selectedType?.min_weight_in_grams || '',
                                  maxWeight: selectedType?.max_weight_in_grams || '',
                                  packagingType: selectedType?.item_name_new || selectedType?.item_name || '',
                                  isBelowRange: validation.isBelowRange || false,
                                  isAboveRange: validation.isAboveRange || false,
                                  message: validation.message
                                });
                                setShowWeightValidationModal(true);
                              }
                            } else {
                              // If no packaging type selected, show message to select one first
                              setWeightValidationData({
                                weight,
                                minWeight: '',
                                maxWeight: '',
                                packagingType: 'No packaging type selected',
                                isBelowRange: false,
                                isAboveRange: false,
                                message: `Weight (${weight}g) entered. Please select a Component Packaging Type first to validate against the recommended range.`
                              });
                              setShowWeightValidationModal(true);
                            }
                          }
                        }}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                      />
                    </div>

                    {/* Component Weight Unit of Measure */}
                    <div className="col-md-6">
                      <label>Component Weight Unit of Measure <span style={{ color: 'red' }}>*</span></label>
                      <select
                        value={editComponentData.componentWeightUnitOfMeasure}
                        onChange={(e) => setEditComponentData({ ...editComponentData, componentWeightUnitOfMeasure: e.target.value })}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px',
                          appearance: 'none',
                          backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                          backgroundRepeat: 'no-repeat',
                          backgroundPosition: 'right 8px center',
                          backgroundSize: '16px',
                          paddingRight: '32px',
                          cursor: 'pointer',
                          backgroundColor: '#fff',
                          transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = '#30ea03';
                          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = '#ddd';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = '#30ea03';
                          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                          e.currentTarget.style.outline = 'none';
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = '#ddd';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <option value="">Select Weight UoM</option>
                        {masterData?.component_uoms?.filter(item => item.is_active).map((item) => (
                          <option key={item.id} value={item.item_name}>
                            {item.item_name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Recycling and Material Information - Third Collapsible Section */}
            <div style={{ marginBottom: '24px' }}>
              <div
                style={{
                  backgroundColor: '#000',
                  padding: '15px 20px',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  borderRadius: '8px',
                  transition: 'background-color 0.2s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#333'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#000'}
                onClick={() => setShowRecyclingComponentFields(!showRecyclingComponentFields)}
              >
                <div style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '12px',
                  color: '#fff',
                  fontWeight: '500',
                  fontSize: '14px'
                }}>
                  <div style={{
                    width: '20px',
                    height: '20px',
                    borderRadius: '50%',
                    border: '1px solid #fff',
                    backgroundColor: 'transparent',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '12px',
                    color: '#fff'
                  }}>
                    {showRecyclingComponentFields ? '−' : '+'}
                  </div>
                  Recycling and Material Information
                  {(() => {
                    const recyclingFields = ['percentPostConsumer', 'percentPostIndustrial', 'percentChemical', 'percentBioSourced'];
                    const hasRecyclingErrors = recyclingFields.some(field => editComponentErrors[field as keyof EditComponentErrors] !== '');
                    return hasRecyclingErrors ? (
                      <span style={{ 
                        color: '#dc3545', 
                        fontSize: '12px', 
                        marginLeft: '8px',
                        fontWeight: 'bold'
                      }}>
                        ⚠️ Has Errors
                      </span>
                    ) : null;
                  })()}
                </div>
              </div>

              {showRecyclingComponentFields && (
                <div style={{ 
                  padding: '20px',
                  border: '1px solid #dee2e6',
                  borderTop: 'none',
                  borderRadius: '0 0 8px 8px',
                  backgroundColor: '#fff'
                }}>
                  <div className="row">
                    {/* Combined percentage validation error */}
                    {editComponentErrors.percentageSum && (
                      <div className="col-12">
                        <div style={{ 
                          color: 'red', 
                          fontSize: '14px', 
                          fontWeight: '600',
                          backgroundColor: '#ffe6e6',
                          border: '1px solid #ffcccc',
                          borderRadius: '4px',
                          padding: '8px 12px',
                          marginBottom: '16px'
                        }}>
                          <i className="ri-error-warning-line" style={{ marginRight: '6px' }}></i>
                          {editComponentErrors.percentageSum}
                        </div>
                      </div>
                    )}
                    {/* % Mechanical Post-Consumer Recycled Content */}
                    <div className="col-md-6">
                      <label>% Mechanical Post-Consumer Recycled Content (inc. Chemical) <span style={{ color: 'red' }}>*</span></label>
                      <input
                        type="number"
                        value={editComponentData.percentPostConsumer}
                        onChange={(e) => {
                          setEditComponentData({ ...editComponentData, percentPostConsumer: e.target.value });
                          setEditComponentErrors(prev => ({ ...prev, percentageSum: '' }));
                        }}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                        placeholder="Percentage"
                      />
                      {editComponentErrors.percentPostConsumer && !editComponentErrors.percentageSum && (
                        <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                          {editComponentErrors.percentPostConsumer}
                        </div>
                      )}
                    </div>

                    {/* % Mechanical Post-Industrial Recycled Content */}
                    <div className="col-md-6">
                      <label>% Mechanical Post-Industrial Recycled Content <span style={{ color: 'red' }}>*</span></label>
                      <input
                        type="number"
                        value={editComponentData.percentPostIndustrial}
                        onChange={(e) => {
                          setEditComponentData({ ...editComponentData, percentPostIndustrial: e.target.value });
                          setEditComponentErrors(prev => ({ ...prev, percentageSum: '' }));
                        }}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                        placeholder="Percentage"
                      />
                      {editComponentErrors.percentPostIndustrial && !editComponentErrors.percentageSum && (
                        <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                          {editComponentErrors.percentPostIndustrial}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="row" style={{ marginTop: '20px' }}>
                    {/* % Chemical Recycled Content */}
                    <div className="col-md-6">
                      <label>% Chemical Recycled Content <span style={{ color: 'red' }}>*</span></label>
                      <input
                        type="number"
                        value={editComponentData.percentChemical}
                        onChange={(e) => {
                          setEditComponentData({ ...editComponentData, percentChemical: e.target.value });
                          setEditComponentErrors(prev => ({ ...prev, percentageSum: '' }));
                        }}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                        placeholder="Percentage"
                      />
                      {editComponentErrors.percentChemical && !editComponentErrors.percentageSum && (
                        <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                          {editComponentErrors.percentChemical}
                        </div>
                      )}
                    </div>

                    {/* % Bio-sourced */}
                    <div className="col-md-6">
                      <label>% Bio-sourced? <span style={{ color: 'red' }}>*</span></label>
                      <input
                        type="number"
                        value={editComponentData.percentBioSourced}
                        onChange={(e) => {
                          setEditComponentData({ ...editComponentData, percentBioSourced: e.target.value });
                          setEditComponentErrors(prev => ({ ...prev, percentageSum: '' }));
                        }}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                        placeholder="Percentage"
                      />
                      {editComponentErrors.percentBioSourced && !editComponentErrors.percentageSum && (
                        <div style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
                          {editComponentErrors.percentBioSourced}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="row" style={{ marginTop: '20px' }}>
                    {/* Material Structure */}
                    <div className="col-md-6">
                      <label>Material structure - multimaterials only (with % wt)</label>
                      <input
                        type="text"
                        value={editComponentData.materialStructure}
                        onChange={(e) => setEditComponentData({ ...editComponentData, materialStructure: e.target.value })}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                      />
                    </div>

                    {/* Packaging Colour */}
                    <div className="col-md-6">
                      <label>Component packaging colour / opacity</label>
                      <input
                        type="text"
                        value={editComponentData.packagingColour}
                        onChange={(e) => setEditComponentData({ ...editComponentData, packagingColour: e.target.value })}
                        className="form-control"
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Additional Component Information - Non-Collapsible Section */}
            {/* <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                padding: '20px',
                border: '1px solid #dee2e6',
                borderRadius: '8px',
                backgroundColor: '#fff'
              }}>
                <div className="row"> */}
                  
                  {/* <div className="col-md-6">
                    <label>
                      CH Pack
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Enter CH Pack value"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <input
                      type="text"
                      value={editComponentData.chPack || ''}
                      onChange={(e) => setEditComponentData({ ...editComponentData, chPack: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                      placeholder="Enter CH Pack value"
                    />
                  </div>

                  <div className="col-md-6">
                    <label>
                      KPIS for Evidence Mapping
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Choose one or more categories for file upload."
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <MultiSelect
                      options={[
                        { value: '1', label: 'Weight' },
                        { value: '2', label: 'Weight UoM' },
                        { value: '3', label: 'Packaging Type' },
                        { value: '4', label: 'Material Type' }
                      ]}
                      selectedValues={selectedCategories}
                      onSelectionChange={(categories) => {
                        setSelectedCategories(categories);
                        setCategoryError(''); 
                        setEditComponentData({ 
                          ...editComponentData, 
                          kpisEvidenceMapping: categories.join(',') 
                        });
                      }}
                      placeholder="Select Categories..."
                    />
                    {categoryError && (
                      <div style={{ 
                        color: '#dc3545', 
                        fontSize: '12px', 
                        marginTop: '4px' 
                      }}>
                        {categoryError}
                      </div>
                    )}
                  </div> */}
                {/* </div>

                <div className="row" style={{ marginTop: '20px' }}>
                  */}
                  {/* <div className="col-md-6">
                    <label>
                      Browse Files
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Upload files"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <input
                        type="file"
                        multiple
                        onChange={(e) => {
                          const files = Array.from(e.target.files || []);
                          setSelectedFiles(files);
                        }}
                        style={{ 
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px',
                          flex: 1
                        }}
                      />
                      <button
                        type="button"
                        className="btn"
                        style={{ 
                          backgroundColor: 'rgb(48, 234, 3)', 
                          border: 'none', 
                          color: '#000', 
                          fontWeight: '600',
                          borderRadius: '8px',
                          fontSize: '12px',
                          cursor: 'pointer',
                          padding: '8px 12px',
                          whiteSpace: 'nowrap'
                        }}
                        onClick={() => {
                          if (selectedCategories.length > 0 && selectedFiles.length > 0) {
                           
                            const alreadyAssignedCategories = selectedCategories.filter(category => 
                              uploadedFiles.some(upload => 
                                upload.categories.includes(category)
                              )
                            );

                            if (alreadyAssignedCategories.length > 0) {
                              const categoryNames = alreadyAssignedCategories.map(cat => {
                                const categoryName = cat === '1' ? 'Weight' : 
                                                    cat === '2' ? 'Weight UoM' : 
                                                    cat === '3' ? 'Packaging Type' : 
                                                    cat === '4' ? 'Material Type' : `Category ${cat}`;
                                return categoryName;
                              }).join(', ');
                              setCategoryError(`${categoryNames} ${alreadyAssignedCategories.length === 1 ? 'is' : 'are'} already assigned to another file. Please remove ${alreadyAssignedCategories.length === 1 ? 'it' : 'them'} from the other file first.`);
                              return;
                            }

                            const newUpload = {
                              id: Date.now().toString(),
                              categories: selectedCategories,
                              files: selectedFiles
                            };
                            setUploadedFiles(prev => [...prev, newUpload]);
                            setCategoryError(''); 
                            setSelectedFiles([]); 
                          }
                        }}
                        disabled={selectedCategories.length === 0 || selectedFiles.length === 0}
                      >
                        + Add
                      </button>
                    </div>
                    {categoryError && (
                      <div style={{ 
                        color: '#dc3545', 
                        fontSize: '12px', 
                        marginTop: '4px' 
                      }}>
                        {categoryError}
                      </div>
                    )}
                  </div> */}

                  {/* Component packaging level */}
                  {/* <div className="col-md-6">
                    <label>
                      Component packaging level
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Select packaging level"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <select
                      value={editComponentData.componentPackagingLevel || ''}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentPackagingLevel: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px',
                        appearance: 'none',
                        backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6,9 12,15 18,9\'%3e%3c/polyline%3e%3c/svg%3e")',
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 8px center',
                        backgroundSize: '16px',
                        paddingRight: '32px',
                        cursor: 'pointer',
                        backgroundColor: '#fff',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(48, 234, 3, 0.2)';
                        e.currentTarget.style.outline = 'none';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = '#ddd';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <option value="">Select Packaging Level</option>
                      <option value="1">Level 1 - Primary</option>
                      <option value="2">Level 2 - Secondary</option>
                      <option value="3">Level 3 - Tertiary</option>
                      <option value="4">Level 4 - Transport</option>
                      <option value="5">Level 5 - Sales</option>
                    </select>
                  </div> */}
                {/* </div>

                <div className="row" style={{ marginTop: '20px' }}>
                  */}
                  {/* <div className="col-md-6">
                    <label>
                      Component dimensions (3D - LxWxH, 2D - LxW)
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Enter component dimensions"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <input
                      type="text"
                      value={editComponentData.componentDimensions || ''}
                      onChange={(e) => setEditComponentData({ ...editComponentData, componentDimensions: e.target.value })}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                      placeholder="Enter dimensions (e.g., 10x5x3 cm)"
                    />
                  </div>

               
                  <div className="col-md-6">
                    <label>
                      Evidence of % of chemical recycled or bio-source
                      <span 
                        style={{ 
                          marginLeft: '8px', 
                          cursor: 'pointer', 
                          color: '#888',
                          fontSize: '16px',
                          transition: 'color 0.2s ease'
                        }} 
                        title="Upload evidence files"
                      >
                        <i className="ri-information-line"></i>
                      </span>
                    </label>
                    <input
                      type="file"
                      multiple
                      onChange={(e) => {
                        const files = Array.from(e.target.files || []);
                        setEditComponentData({ ...editComponentData, evidenceChemicalRecycled: files });
                      }}
                      className="form-control"
                      style={{ 
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                  </div> */}
                {/* </div>
              </div>
            </div> */}

            {/* Display Uploaded Files Table */}
            {uploadedFiles.length > 0 && (
              <div className="row" style={{ marginTop: '24px' }}>
                <div className="col-12">
                  <div style={{ 
                    background: '#fff', 
                    borderRadius: '8px', 
                    border: '1px solid #e9ecef',
                    overflow: 'hidden',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                  }}>
                    <div style={{ padding: '0 24px 24px 24px' }}>
                      <div className="table-responsive">
                        <table style={{ 
                          width: '100%', 
                          borderCollapse: 'collapse',
                          backgroundColor: '#fff'
                        }}>
                          <thead>
                            <tr style={{ backgroundColor: '#000' }}>
                              <th style={{ 
                                padding: '16px 20px', 
                                fontSize: '14px', 
                                fontWeight: '600',
                                textAlign: 'left',
                                borderBottom: '1px solid #e9ecef',
                                color: '#fff'
                              }}>
                                Category
                              </th>
                              <th style={{ 
                                padding: '16px 20px', 
                                fontSize: '14px', 
                                fontWeight: '600',
                                textAlign: 'left',
                                borderBottom: '1px solid #e9ecef',
                                color: '#fff'
                              }}>
                                Files
                              </th>
                              <th style={{ 
                                padding: '16px 20px', 
                                fontSize: '14px', 
                                fontWeight: '600',
                                textAlign: 'center',
                                borderBottom: '1px solid #e9ecef',
                                width: '100px',
                                color: '#fff'
                              }}>
                                Action
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {uploadedFiles.map((upload, index) => (
                              <tr key={upload.id} style={{ 
                                backgroundColor: index % 2 === 0 ? '#fff' : '#f8f9fa',
                                transition: 'background-color 0.2s ease'
                              }}>
                                <td style={{ 
                                  padding: '16px 20px', 
                                  fontSize: '14px',
                                  borderBottom: '1px solid #e9ecef',
                                  color: '#333'
                                }}>
                                  {upload.categoryName || upload.categories.map(cat => {
                                    // Map category number to category name
                                    const categoryName = cat === '1' ? 'Weight' : 
                                                        cat === '2' ? 'Weight UoM' : 
                                                        cat === '3' ? 'Packaging Type' : 
                                                        cat === '4' ? 'Material Type' : `Category ${cat}`;
                                    return categoryName;
                                  }).join(', ')}
                                </td>
                                <td style={{ 
                                  padding: '16px 20px', 
                                  fontSize: '14px',
                                  borderBottom: '1px solid #e9ecef',
                                  color: '#333'
                                }}>
                                  {upload.files.map(file => file.name).join(', ')}
                                </td>
                                <td style={{ 
                                  padding: '16px 20px', 
                                  textAlign: 'center',
                                  borderBottom: '1px solid #e9ecef'
                                }}>
                                  <button
                                    type="button"
                                    style={{
                                      backgroundColor: '#dc3545',
                                      border: 'none',
                                      color: '#fff',
                                      padding: '8px 12px',
                                      fontSize: '13px',
                                      borderRadius: '6px',
                                      cursor: 'pointer',
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                      minWidth: '40px'
                                    }}
                                    onClick={() => {
                                      setUploadedFiles(prev => prev.filter(item => item.id !== upload.id));
                                    }}
                                    title="Delete"
                                  >
                                    <i className="ri-delete-bin-line" style={{ fontSize: '14px' }}></i>
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="modal-footer" style={{ 
            background: '#fff', 
            borderTop: '2px solid #000', 
            display: 'flex', 
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '15px 25px',
            borderRadius: '0 0 12px 12px'
          }}>
            {/* Left side - Component validity date fields */}
            <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
              {/* Component validity date - From */}
              <div>
                <label style={{ 
                  fontSize: '12px', 
                  fontWeight: '600', 
                  color: '#333', 
                  marginBottom: '4px',
                  display: 'block'
                }}>
                  Component validity date - From <span style={{ color: 'red' }}>*</span>
                </label>
                <input 
                  type="date" 
                  className={`form-control${editComponentErrors.validityFrom ? ' is-invalid' : ''}`}
                  name="validityFrom"
                  data-field="validityFrom"
                  value={editComponentData.validityFrom} 
                  onChange={e => {
                    setEditComponentData({ ...editComponentData, validityFrom: e.target.value });
                    if (editComponentErrors.validityFrom) {
                      setEditComponentErrors(prev => ({ ...prev, validityFrom: '' }));
                    }
                  }} 
                  style={{
                    width: '160px',
                    padding: '5px 8px',
                    border: '1px solid #ced4da',
                    borderRadius: '4px',
                    fontSize: '12px',
                    backgroundColor: '#fff'
                  }}
                />
                {editComponentErrors.validityFrom && <div style={{ color: 'red', fontSize: '10px', marginTop: '1px' }}>{editComponentErrors.validityFrom}</div>}
              </div>
              
              {/* Component validity date - To */}
              <div>
                <label style={{ 
                  fontSize: '12px', 
                  fontWeight: '600', 
                  color: '#333', 
                  marginBottom: '4px',
                  display: 'block'
                }}>
                  Component validity date - To <span style={{ color: 'red' }}>*</span>
                </label>
                <input 
                  type="date" 
                  className={`form-control${editComponentErrors.validityTo ? ' is-invalid' : ''}`}
                  name="validityTo"
                  data-field="validityTo"
                  value={editComponentData.validityTo} 
                  onChange={e => {
                    setEditComponentData({ ...editComponentData, validityTo: e.target.value });
                    if (editComponentErrors.validityTo) {
                      setEditComponentErrors(prev => ({ ...prev, validityTo: '' }));
                    }
                  }} 
                  style={{
                    width: '160px',
                    padding: '5px 8px',
                    border: '1px solid #ced4da',
                    borderRadius: '4px',
                    fontSize: '12px',
                    backgroundColor: '#fff'
                  }}
                />
                {editComponentErrors.validityTo && <div style={{ color: 'red', fontSize: '10px', marginTop: '1px' }}>{editComponentErrors.validityTo}</div>}
              </div>
            </div>

            {/* Right side - Replace and Update buttons */}
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                                            {/* Replace button */}
                <button
                  type="button"
                  className="btn"
                  style={{ 
                    backgroundColor: '#ffc107', 
                    border: 'none', 
                    color: '#000', 
                    fontWeight: 600,
                    borderRadius: '8px',
                    fontSize: '12px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '6px 14px'
                  }}
                  onClick={() => {
                    console.log('Replace button clicked!'); // Debug log
                    console.log('About to call handleEditComponentSave with REPLACE');
                    handleEditComponentSave('REPLACE');
                  }}
               >
                 <i className="ri-refresh-line" style={{ fontSize: '14px' }} />
                 Create new version
               </button>

                              {/* Update button */}
                <button
                  type="button"
                  className="btn"
                  style={{ 
                    backgroundColor: 'rgb(48, 234, 3)', 
                    border: 'none', 
                    color: '#000', 
                    fontWeight: 600,
                    borderRadius: '8px',
                    fontSize: '12px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '6px 14px'
                  }}
                  onClick={() => {
                    console.log('Update button clicked!'); // Debug log
                    console.log('About to show confirmation modal');
                    setShowConfirmationModal(true);
                  }}
                  disabled={editComponentLoading}
                >
                {editComponentLoading ? (
                  <>
                    <i className="ri-loader-4-line" style={{ fontSize: '14px', animation: 'spin 1s linear infinite' }} />
                    Updating...
                  </>
                ) : (
                  <>
                    Update Component
                    <i className="ri-save-line" style={{ fontSize: '14px' }} />
                  </>
                )}
              </button>
            </div>
          </div>
                 </div>
       </div>
       
       {/* Confirmation Modal */}
       {showConfirmationModal && (
         <div style={{
           position: 'fixed',
           top: 0,
           left: 0,
           right: 0,
           bottom: 0,
           backgroundColor: 'rgba(0, 0, 0, 0.7)',
           display: 'flex',
           alignItems: 'center',
           justifyContent: 'center',
           zIndex: 99999
         }}>
           <div style={{
             background: '#fff',
             borderRadius: '12px',
             width: '90%',
             maxWidth: '500px',
             boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
             overflow: 'hidden'
           }}>
             {/* Modal Header */}
             <div style={{
               background: 'linear-gradient(135deg, #ffc107 0%, #ff9800 100%)',
               color: '#000',
               padding: '20px 25px',
               borderBottom: '2px solid #000',
               display: 'flex',
               justifyContent: 'space-between',
               alignItems: 'center'
             }}>
               <h5 style={{ margin: 0, fontWeight: '600', fontSize: '18px' }}>
                 <i className="ri-question-line me-2" style={{ marginRight: '8px' }}></i>
                 Confirm Component Update
               </h5>
               <button
                 onClick={() => setShowConfirmationModal(false)}
                 style={{
                   background: 'none',
                   border: 'none',
                   fontSize: '24px',
                   cursor: 'pointer',
                   color: '#000',
                   fontWeight: 'bold'
                 }}
               >
                 ×
               </button>
             </div>
             
             {/* Modal Body */}
             <div style={{ padding: '25px' }}>
               <div style={{ marginBottom: '20px' }}>
                 <p style={{ 
                   fontSize: '16px', 
                   color: '#333', 
                   margin: '0 0 15px 0',
                   lineHeight: '1.5'
                 }}>
                   <strong>Warning:</strong> This component is used across multiple SKUs.
                 </p>
                 <p style={{ 
                   fontSize: '14px', 
                   color: '#666', 
                   margin: '0 0 20px 0',
                   lineHeight: '1.5'
                 }}>
                   All changes will apply to <strong>all related SKUs</strong> that use this component.
                 </p>
                 <div style={{
                   background: '#fff3cd',
                   border: '1px solid #ffeaa7',
                   borderRadius: '8px',
                   padding: '15px',
                   marginBottom: '20px'
                 }}>
                   <p style={{ 
                     fontSize: '14px', 
                     color: '#856404', 
                     margin: '0',
                     fontWeight: '500'
                   }}>
                     <i className="ri-information-line" style={{ marginRight: '8px' }}></i>
                     <strong>Impact:</strong> Updating this component will affect all SKUs that reference it.
                   </p>
                 </div>
               </div>
               
               <div style={{ 
                 display: 'flex', 
                 gap: '15px', 
                 justifyContent: 'center',
                 flexWrap: 'wrap'
               }}>
                 {/* Cancel Button */}
                 <button
                   onClick={() => setShowConfirmationModal(false)}
                   style={{
                     backgroundColor: '#6c757d',
                     border: 'none',
                     color: '#fff',
                     fontWeight: '600',
                     borderRadius: '8px',
                     fontSize: '14px',
                     cursor: 'pointer',
                     padding: '12px 24px',
                     minWidth: '120px'
                   }}
                 >
                   <i className="ri-close-line" style={{ marginRight: '8px' }}></i>
                   Cancel
                 </button>
                 
                                   {/* Replace Component Button */}
                  <button
                    onClick={() => {
                      setShowConfirmationModal(false);
                      handleEditComponentSave('REPLACE');
                    }}
                   style={{
                     backgroundColor: '#ffc107',
                     border: 'none',
                     color: '#000',
                     fontWeight: '600',
                     borderRadius: '8px',
                     fontSize: '14px',
                     cursor: 'pointer',
                     padding: '12px 24px',
                     minWidth: '120px'
                   }}
                 >
                   <i className="ri-refresh-line" style={{ marginRight: '8px' }}></i>
                   Create new version
                 </button>
                 
                                   {/* Update Anyway Button */}
                  <button
                    onClick={() => {
                      setShowConfirmationModal(false);
                      handleEditComponentSave('UPDATE');
                    }}
                   style={{
                     backgroundColor: '#dc3545',
                     border: 'none',
                     color: '#fff',
                     fontWeight: '600',
                     borderRadius: '8px',
                     fontSize: '14px',
                     cursor: 'pointer',
                     padding: '12px 24px',
                     minWidth: '120px'
                   }}
                 >
                   <i className="ri-warning-line" style={{ marginRight: '8px' }}></i>
                   Update Anyway
                 </button>
               </div>
             </div>
           </div>
         </div>
       )}

       {/* Weight Validation Modal */}
       {showWeightValidationModal && weightValidationData && (
         <div 
           className="modal fade show" 
           style={{ 
             display: 'block', 
             background: 'rgba(0,0,0,0.5)',
             zIndex: 1060,
             animation: 'fadeIn 0.3s ease-out'
           }} 
           tabIndex={-1}
         >
           <div 
             className="modal-dialog modal-dialog-centered" 
             style={{ 
               maxWidth: '420px', 
               margin: '0 auto',
               animation: 'slideIn 0.3s ease-out'
             }}
           >
             <div 
               className="modal-content" 
               style={{ 
                 borderRadius: '12px', 
                 border: 'none',
                 boxShadow: '0 20px 60px rgba(0,0,0,0.3), 0 0 0 1px rgba(255,255,255,0.1)',
                 overflow: 'hidden',
                 background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)'
               }}
             >
               {/* Header with gradient and icon */}
               <div 
                 className="modal-header" 
                 style={{ 
                   background: 'linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%)', 
                   color: '#ffffff', 
                   border: 'none', 
                   padding: '20px 24px 16px',
                   position: 'relative',
                   overflow: 'hidden'
                 }}
               >
                 <div style={{
                   position: 'absolute',
                   top: '-50%',
                   right: '-20px',
                   width: '100px',
                   height: '100px',
                   background: 'rgba(255,255,255,0.1)',
                   borderRadius: '50%',
                   transform: 'rotate(45deg)'
                 }} />
                 <div style={{ display: 'flex', alignItems: 'center', position: 'relative', zIndex: 1 }}>
                   <div style={{
                     width: '40px',
                     height: '40px',
                     background: 'rgba(255,255,255,0.2)',
                     borderRadius: '50%',
                     display: 'flex',
                     alignItems: 'center',
                     justifyContent: 'center',
                     marginRight: '12px',
                     backdropFilter: 'blur(10px)'
                   }}>
                     <i className="ri-alert-line" style={{ fontSize: '20px', color: '#fff' }} />
                   </div>
                   <div>
                     <h5 
                       className="modal-title" 
                       style={{ 
                         fontWeight: '700', 
                         margin: 0,
                         fontSize: '18px',
                         lineHeight: '1.2',
                         textShadow: '0 1px 2px rgba(0,0,0,0.1)'
                       }}
                     >
                       Please review the weight information
                     </h5>
                     <p style={{ 
                       margin: '4px 0 0', 
                       fontSize: '13px', 
                       opacity: 0.9,
                       fontWeight: '400'
                     }}>
                     </p>
                   </div>
                 </div>
               </div>

               {/* Body with enhanced styling */}
               <div 
                 className="modal-body" 
                 style={{ 
                   padding: '24px',
                   background: '#ffffff'
                 }}
               >
                 {/* Weight info card */}
                 <div 
                   style={{
                     background: 'linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)',
                     padding: '16px 20px',
                     borderRadius: '10px',
                     marginBottom: '20px',
                     border: '1px solid #dee2e6',
                     position: 'relative',
                     overflow: 'hidden'
                   }}
                 >
                   <div style={{
                     position: 'absolute',
                     top: 0,
                     left: 0,
                     right: 0,
                     height: '3px',
                     background: 'linear-gradient(90deg, #ff6b6b, #ffa726, #66bb6a)'
                   }} />
                   
                   <div style={{ display: 'flex', alignItems: 'center', marginBottom: '12px' }}>
                     <div style={{
                       width: '32px',
                       height: '32px',
                       background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                       borderRadius: '8px',
                       display: 'flex',
                       alignItems: 'center',
                       justifyContent: 'center',
                       marginRight: '12px'
                     }}>
                       <i className="ri-scales-3-line" style={{ fontSize: '16px', color: '#fff' }} />
                     </div>
                     <div>
                       <div style={{ fontSize: '14px', fontWeight: '600', color: '#495057', marginBottom: '2px' }}>
                         Entered Weight
                       </div>
                       <div style={{ fontSize: '20px', fontWeight: '700', color: '#212529' }}>
                         {weightValidationData.weight}g
                       </div>
                     </div>
                   </div>

                   {weightValidationData.minWeight && weightValidationData.maxWeight && (
                     <div style={{ 
                       fontSize: '13px'
                     }}>
                       <div style={{ color: '#6c757d', fontWeight: '500', marginBottom: '4px' }}>
                         Recommended Range
                       </div>
                       <div style={{ color: '#212529', fontWeight: '600' }}>
                         {weightValidationData.minWeight}g - {weightValidationData.maxWeight}g
                       </div>
                     </div>
                   )}
                 </div>

                 {/* Message with enhanced styling */}
                 <div style={{ 
                   background: 'linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%)',
                   padding: '16px 20px',
                   borderRadius: '10px',
                   border: '1px solid #ffc107',
                   position: 'relative',
                   marginBottom: '8px'
                 }}>
                   <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                     <div style={{
                       width: '24px',
                       height: '24px',
                       background: '#ffc107',
                       borderRadius: '50%',
                       display: 'flex',
                       alignItems: 'center',
                       justifyContent: 'center',
                       marginRight: '12px',
                       flexShrink: 0,
                       marginTop: '2px'
                     }}>
                       <i className="ri-information-line" style={{ fontSize: '14px', color: '#856404' }} />
                     </div>
                     <div style={{ 
                       fontSize: '14px', 
                       lineHeight: '1.5',
                       color: '#856404',
                       fontWeight: '500'
                     }}>
                       {weightValidationData.message}
                     </div>
                   </div>
                 </div>
               </div>

               {/* Enhanced footer with better buttons */}
               <div 
                 className="modal-footer" 
                 style={{ 
                   padding: '20px 24px',
                   background: '#f8f9fa',
                   borderTop: '1px solid #dee2e6',
                   display: 'flex',
                   justifyContent: 'flex-end',
                   gap: '12px'
                 }}
               >
                 <button
                   type="button"
                   className="btn"
                   onClick={handleWeightValidationCancel}
                   style={{
                     background: 'linear-gradient(135deg, #6c757d 0%, #5a6268 100%)',
                     color: '#ffffff',
                     border: 'none',
                     padding: '10px 20px',
                     borderRadius: '8px',
                     fontSize: '14px',
                     fontWeight: '600',
                     cursor: 'pointer',
                     transition: 'all 0.2s ease',
                     boxShadow: '0 2px 8px rgba(108, 117, 125, 0.3)',
                     minWidth: '100px'
                   }}
                   onMouseOver={(e) => {
                     e.currentTarget.style.transform = 'translateY(-1px)';
                     e.currentTarget.style.boxShadow = '0 4px 12px rgba(108, 117, 125, 0.4)';
                   }}
                   onMouseOut={(e) => {
                     e.currentTarget.style.transform = 'translateY(0)';
                     e.currentTarget.style.boxShadow = '0 2px 8px rgba(108, 117, 125, 0.3)';
                   }}
                 >
                   <i className="ri-close-line" style={{ marginRight: '6px' }} />
                   Cancel
                 </button>
                 <button
                   type="button"
                   className="btn"
                   onClick={handleWeightValidationConfirm}
                   style={{
                     background: 'linear-gradient(135deg, #ffc107 0%, #ffb300 100%)',
                     color: '#000000',
                     border: 'none',
                     padding: '10px 20px',
                     borderRadius: '8px',
                     fontSize: '14px',
                     fontWeight: '700',
                     cursor: 'pointer',
                     transition: 'all 0.2s ease',
                     boxShadow: '0 2px 8px rgba(255, 193, 7, 0.3)',
                     minWidth: '140px'
                   }}
                   onMouseOver={(e) => {
                     e.currentTarget.style.transform = 'translateY(-1px)';
                     e.currentTarget.style.boxShadow = '0 4px 12px rgba(255, 193, 7, 0.4)';
                   }}
                   onMouseOut={(e) => {
                     e.currentTarget.style.transform = 'translateY(0)';
                     e.currentTarget.style.boxShadow = '0 2px 8px rgba(255, 193, 7, 0.3)';
                   }}
                 >
                   <i className="ri-check-line" style={{ marginRight: '6px' }} />
                   Continue Anyway
                 </button>
               </div>
             </div>
           </div>
         </div>
       )}

       {/* Add CSS animations */}
       <style dangerouslySetInnerHTML={{
         __html: `
           @keyframes fadeIn {
             from { opacity: 0; }
             to { opacity: 1; }
           }
           
           @keyframes slideIn {
             from { 
               opacity: 0;
               transform: translateY(-30px) scale(0.95);
             }
             to { 
               opacity: 1;
               transform: translateY(0) scale(1);
             }
           }
         `
       }} />
     </div>
   );
 };

export default EditComponentModal;
