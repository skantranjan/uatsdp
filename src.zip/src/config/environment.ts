// Environment configuration for different deployment stages
export interface EnvironmentConfig {
  API_BASE_URL: string;
  ORIGIN: string;
  IS_PRODUCTION: boolean;
  // SSO Configuration
  SSO_CLIENT_ID: string;
  SSO_TENANT_ID: string;
  SSO_AUTHORITY: string;
  SSO_REDIRECT_URI: string;
  SSO_POST_LOGOUT_REDIRECT_URI: string;
  SSO_SCOPES: string[];
  ENVIRONMENT_NAME: string;
}

// Local development environment (localhost)
const localConfig: EnvironmentConfig = {
  API_BASE_URL: 'https://haleon-api-dev.apigee.net/Sustainibility-portal-channel/v1',
  ORIGIN: 'http://localhost:3000',
  IS_PRODUCTION: false,
  SSO_CLIENT_ID: '6d727ebc-0df4-4edb-8ad3-afdbc9d2264d', // DEV client for local testing
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'http://localhost:3000/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'http://localhost:3000/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'LOCAL'
};

// Development environment (dev server)
const devConfig: EnvironmentConfig = {
  API_BASE_URL: 'https://haleon-api-dev.apigee.net/Sustainibility-portal-channel/v1',
  ORIGIN: 'https://sustainability-data-portal.eip.dev.haleon.com',
  IS_PRODUCTION: false,
  SSO_CLIENT_ID: '6d727ebc-0df4-4edb-8ad3-afdbc9d2264d', // DEV client
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'https://sustainability-data-portal.eip.dev.haleon.com/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'https://sustainability-data-portal.eip.dev.haleon.com/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'DEV'
};

// UAT environment
const uatConfig: EnvironmentConfig = {
  API_BASE_URL: 'https://haleon-api-uat.apigee.net/Sustainibility-portal-channel/v1', // UAT API URL
  ORIGIN: 'https://sustainability-data-portal.eip.uat.haleon.com', // UAT URL
  IS_PRODUCTION: false,
  SSO_CLIENT_ID: '4d23b47c-e00f-447c-8a2b-e2a4bd3f2ecb', // UAT client
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'https://sustainability-data-portal.eip.uat.haleon.com/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'https://sustainability-data-portal.eip.uat.haleon.com/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'UAT'
};

// Production environment
const prodConfig: EnvironmentConfig = {
  API_BASE_URL: '/api', // Use proxy in production
  ORIGIN: 'https://sustainability-data-portal.eip.prod.haleon.com', // PROD URL
  IS_PRODUCTION: true,
  SSO_CLIENT_ID: 'TBD', // Production client ID - to be configured
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'https://sustainability-data-portal.eip.prod.haleon.com/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'https://sustainability-data-portal.eip.prod.haleon.com/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'PROD'
};

// Determine which environment we're running in
const getEnvironment = (): EnvironmentConfig => {
  const hostname = window.location.hostname;
  
  // Environment detection based on hostname
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    return localConfig;
  }
  
  if (hostname.includes('dev')) {
    return devConfig;
  }
  
  if (hostname.includes('uat')) {
    return uatConfig;
  }
  
  if (hostname.includes('prod') || hostname.includes('production')) {
    return prodConfig;
  }
  
  // Check for environment variables (useful for build-time configuration)
  if (process.env.REACT_APP_ENVIRONMENT === 'production') {
    return prodConfig;
  }
  
  if (process.env.REACT_APP_ENVIRONMENT === 'uat') {
    return uatConfig;
  }
  
  if (process.env.REACT_APP_ENVIRONMENT === 'dev') {
    return devConfig;
  }
  
  if (process.env.REACT_APP_ENVIRONMENT === 'local') {
    return localConfig;
  }
  
  // Default to development
  return devConfig;
};

export const ENV_CONFIG = getEnvironment();

// Log environment info in development only
if (!ENV_CONFIG.IS_PRODUCTION) {
  console.log(`🌍 Environment: ${ENV_CONFIG.ENVIRONMENT_NAME}`);
  console.log(`🔗 API Base URL: ${ENV_CONFIG.API_BASE_URL}`);
  console.log(`🔐 SSO Client ID: ${ENV_CONFIG.SSO_CLIENT_ID}`);
  console.log(`🌐 Origin: ${ENV_CONFIG.ORIGIN}`);
}
