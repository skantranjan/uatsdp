import { Configuration, PopupRequest } from "@azure/msal-browser";
import { ENV_CONFIG } from './environment';

// MSAL configuration for Azure AD - dynamically configured based on environment
export const msalConfig: Configuration = {
  auth: {
    clientId: ENV_CONFIG.SSO_CLIENT_ID,
    authority: ENV_CONFIG.SSO_AUTHORITY,
    redirectUri: ENV_CONFIG.SSO_REDIRECT_URI,
    postLogoutRedirectUri: ENV_CONFIG.SSO_POST_LOGOUT_REDIRECT_URI,
  },
  cache: {
    cacheLocation: "sessionStorage", // Use sessionStorage for better security
    storeAuthStateInCookie: false, // Set to true if you have issues with IE11/Edge
  },
  system: {
    loggerOptions: {
      loggerCallback: (level: any, message: string, containsPii: boolean) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case 0:
            console.log(message);
            return;
          case 1:
            console.warn(message);
            return;
          case 2:
            console.error(message);
            return;
          case 3:
            console.info(message);
            return;
          default:
            console.log(message);
            return;
        }
      },
      logLevel: process.env.NODE_ENV === 'development' ? 0 : 2, // Verbose in dev, Error in prod
    },
  },
};

// Login request configuration - dynamically configured based on environment
export const loginRequest: PopupRequest = {
  scopes: ENV_CONFIG.SSO_SCOPES,
  prompt: "select_account", // Force account selection
};

// Logout request configuration - dynamically configured based on environment
export const logoutRequest = {
  postLogoutRedirectUri: ENV_CONFIG.SSO_POST_LOGOUT_REDIRECT_URI,
};

// Graph API endpoints for user info
export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
};
