// Environment configuration for different deployment stages
export interface EnvironmentConfig {
  API_BASE_URL: string;
  ORIGIN: string;
  IS_PRODUCTION: boolean;
  // SSO Configuration
  SSO_CLIENT_ID: string;
  SSO_TENANT_ID: string;
  SSO_AUTHORITY: string;
  SSO_REDIRECT_URI: string;
  SSO_POST_LOGOUT_REDIRECT_URI: string;
  SSO_SCOPES: string[];
  ENVIRONMENT_NAME: string;
  // HMAC Configuration
  HMAC_ID: string;
  HMAC_KEY: string;
  HMAC_API_KEY: string;
  HMAC_STATIC_TOKEN?: string;
}

// Local development environment (localhost)
const localConfig: EnvironmentConfig = {
  API_BASE_URL: 'https://haleon-api-dev.apigee.net/Sustainibility-portal-channel/v1',
  ORIGIN: 'http://localhost:3000',
  IS_PRODUCTION: false,
  SSO_CLIENT_ID: '6d727ebc-0df4-4edb-8ad3-afdbc9d2264d', // DEV client for local testing
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'http://localhost:3000/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'http://localhost:3000/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'LOCAL',
  // HMAC Configuration - using DEV credentials for local testing
  HMAC_ID: 'SustainibilityPortal',
  HMAC_KEY: '0KEX8P1I7U9NJHKV1L7XHCVH6QI9XXCS', // DEV HMAC key
  HMAC_API_KEY: 'bGMxYSqsNUb6F88L9rTY3OOMCynzZKAF',
  HMAC_STATIC_TOKEN: undefined // No static token for DEV
};

// Development environment (dev server)
const devConfig: EnvironmentConfig = {
  API_BASE_URL: 'https://haleon-api-dev.apigee.net/Sustainibility-portal-channel/v1',
  ORIGIN: 'https://sustainability-data-portal.eip.dev.haleon.com',
  IS_PRODUCTION: false,
  SSO_CLIENT_ID: '6d727ebc-0df4-4edb-8ad3-afdbc9d2264d', // DEV client
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'https://sustainability-data-portal.eip.dev.haleon.com/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'https://sustainability-data-portal.eip.dev.haleon.com/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'DEV',
  // HMAC Configuration - DEV credentials
  HMAC_ID: 'SustainibilityPortal',
  HMAC_KEY: '0KEX8P1I7U9NJHKV1L7XHCVH6QI9XXCS', // DEV HMAC key
  HMAC_API_KEY: 'bGMxYSqsNUb6F88L9rTY3OOMCynzZKAF',
  HMAC_STATIC_TOKEN: undefined // No static token for DEV
};

// UAT environment
const uatConfig: EnvironmentConfig = {
  API_BASE_URL: 'https://haleon-api-uat.apigee.net/Sustainibility-portal-channel/v1', // UAT API URL
  ORIGIN: 'https://sustainability-data-portal.eip.uat.haleon.com', // UAT URL - this will be used as Origin header
  IS_PRODUCTION: false,
  SSO_CLIENT_ID: '4d23b47c-e00f-447c-8a2b-e2a4bd3f2ecb', // UAT client
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'https://sustainability-data-portal.eip.uat.haleon.com/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'https://sustainability-data-portal.eip.uat.haleon.com/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'UAT',
  // HMAC Configuration - UAT credentials
  HMAC_ID: 'SustainibilityPortal',
  HMAC_KEY: 'JY0EWMIFGYALMASD04XP8QT1IAJCJ9GB', // UAT HMAC key
  HMAC_API_KEY: 'bGMxYSqsNUb6F88L9rTY3OOMCynzZKAF', // UAT API key
  HMAC_STATIC_TOKEN: 'Rv7!aH8@gP4' // UAT static token
};

// Production environment
const prodConfig: EnvironmentConfig = {
  API_BASE_URL: '/api', // Use proxy in production
  ORIGIN: 'https://sustainability-data-portal.eip.prod.haleon.com', // PROD URL
  IS_PRODUCTION: true,
  SSO_CLIENT_ID: 'TBD', // Production client ID - to be configured
  SSO_TENANT_ID: 'd1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_AUTHORITY: 'https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc',
  SSO_REDIRECT_URI: 'https://sustainability-data-portal.eip.prod.haleon.com/ui',
  SSO_POST_LOGOUT_REDIRECT_URI: 'https://sustainability-data-portal.eip.prod.haleon.com/ui',
  SSO_SCOPES: ['User.Read', 'email', 'profile'],
  ENVIRONMENT_NAME: 'PROD',
  // HMAC Configuration - PROD credentials (to be configured)
  HMAC_ID: 'SustainibilityPortal',
  HMAC_KEY: 'TBD', // Production HMAC key - to be configured
  HMAC_API_KEY: 'bGMxYSqsNUb6F88L9rTY3OOMCynzZKAF',
  HMAC_STATIC_TOKEN: 'TBD' // Production static token - to be configured
};

// Determine which environment we're running in
const getEnvironment = (): EnvironmentConfig => {
  // Deep debugging - log everything we can about the current environment
  console.log('🔍 === DEEP ENVIRONMENT DEBUGGING ===');
  console.log('📍 window.location:', window.location);
  console.log('🏠 window.location.hostname:', window.location.hostname);
  console.log('🌐 window.location.href:', window.location.href);
  console.log('🔗 window.location.origin:', window.location.origin);
  console.log('📱 navigator.userAgent:', navigator.userAgent);
  console.log('🌍 window.location.protocol:', window.location.protocol);
  console.log('🔢 window.location.port:', window.location.port);
  
  const hostname = window.location.hostname;
  console.log('🎯 Extracted hostname:', hostname);
  console.log('📏 Hostname length:', hostname.length);
  console.log('🔤 Hostname type:', typeof hostname);
  
  // Test each condition step by step
  console.log('🧪 Testing conditions:');
  console.log('  - Is localhost?', hostname === 'localhost' || hostname === '127.0.0.1');
  console.log('  - Contains "uat"?', hostname.includes('uat'));
  console.log('  - Contains "dev"?', hostname.includes('dev'));
  console.log('  - Is production hostname?', hostname === 'sustainability-data-portal.eip.haleon.com');
  console.log('  - Contains "prod"?', hostname.includes('prod'));
  console.log('  - Contains "production"?', hostname.includes('production'));
  
  // Environment detection based on hostname
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    console.log('✅ Selected: LOCAL environment');
    return localConfig;
  }
  
  // Check for UAT environment
  if (hostname.includes('uat')) {
    console.log('✅ Selected: UAT environment');
    return uatConfig;
  }
  
  // Check for DEV environment
  if (hostname.includes('dev')) {
    console.log('✅ Selected: DEV environment');
    return devConfig;
  }
  
  // Check for PRODUCTION environment
  // Production URL: sustainability-data-portal.eip.haleon.com (no dev/uat in hostname)
  if (hostname === 'sustainability-data-portal.eip.haleon.com' || 
      hostname.includes('prod') || 
      hostname.includes('production')) {
    console.log('✅ Selected: PRODUCTION environment');
    return prodConfig;
  }
  
  // Check for environment variables (useful for build-time configuration)
  console.log('🔧 Checking environment variables:');
  console.log('  - process.env.REACT_APP_ENVIRONMENT:', process.env.REACT_APP_ENVIRONMENT);
  console.log('  - process.env.NODE_ENV:', process.env.NODE_ENV);
  
  if (process.env.REACT_APP_ENVIRONMENT === 'production') {
    console.log('✅ Selected: PRODUCTION environment (from env var)');
    return prodConfig;
  }
  
  if (process.env.REACT_APP_ENVIRONMENT === 'uat') {
    console.log('✅ Selected: UAT environment (from env var)');
    return uatConfig;
  }
  
  if (process.env.REACT_APP_ENVIRONMENT === 'dev') {
    console.log('✅ Selected: DEV environment (from env var)');
    return devConfig;
  }
  
  if (process.env.REACT_APP_ENVIRONMENT === 'local') {
    console.log('✅ Selected: LOCAL environment (from env var)');
    return localConfig;
  }
  
  // Default to development
  console.log('⚠️ No environment matched, defaulting to DEV');
  console.log('🔍 === END DEEP DEBUGGING ===');
  return devConfig;
};

// Don't call getEnvironment() at module load time - it might be too early
// Instead, create a getter function that will be called when needed
let _envConfig: EnvironmentConfig | null = null;

export const getEnvConfig = (): EnvironmentConfig => {
  if (!_envConfig) {
    _envConfig = getEnvironment();
  }
  return _envConfig;
};

// For backward compatibility, export ENV_CONFIG as a getter
export const ENV_CONFIG = new Proxy({} as EnvironmentConfig, {
  get(target, prop) {
    return getEnvConfig()[prop as keyof EnvironmentConfig];
  }
});

// Function to manually test environment detection (can be called from browser console)
export const testEnvironmentDetection = (): void => {
  console.log('🧪 === MANUAL ENVIRONMENT TEST ===');
  console.log('Current time:', new Date().toISOString());
  console.log('Testing environment detection...');
  
  const testResult = getEnvironment();
  
  console.log('🎯 Test Result:');
  console.log('  - Environment Name:', testResult.ENVIRONMENT_NAME);
  console.log('  - API Base URL:', testResult.API_BASE_URL);
  console.log('  - Origin:', testResult.ORIGIN);
  console.log('  - Is Production:', testResult.IS_PRODUCTION);
  console.log('🧪 === END MANUAL TEST ===');
};

// Make test function available globally for easy console access
if (typeof window !== 'undefined') {
  (window as any).testEnvironmentDetection = testEnvironmentDetection;
  
  // Debug HMAC headers for UAT deployment
  (window as any).debugHMACHeaders = () => {
    const config = getEnvConfig();
    console.log('🔍 HMAC Debug Information:');
    console.log('  - Environment:', config.ENVIRONMENT_NAME);
    console.log('  - API Base URL:', config.API_BASE_URL);
    console.log('  - Origin Header:', config.ORIGIN);
    console.log('  - HMAC ID:', config.HMAC_ID);
    console.log('  - HMAC Key:', config.HMAC_KEY.substring(0, 8) + '...');
    console.log('  - API Key:', config.HMAC_API_KEY);
    console.log('  - Static Token:', config.HMAC_STATIC_TOKEN);
    console.log('  - Current URL:', window.location.href);
    console.log('  - Current Origin:', window.location.origin);
  };
  
  console.log('💡 Available console commands:');
  console.log('  - testEnvironmentDetection() - Test environment detection');
  console.log('  - debugHMACHeaders() - Debug HMAC configuration for UAT');
}

// Log environment info when the module is loaded (but environment detection happens lazily)
console.log('🚀 Environment module loaded - environment will be detected when first accessed');

// Additional environment-specific logging - this will trigger environment detection
setTimeout(() => {
  const config = getEnvConfig();
  console.log('='.repeat(60));
  console.log('🚀 APPLICATION ENVIRONMENT DETECTION');
  console.log('='.repeat(60));
  console.log(`🌐 Current URL: ${window.location.href}`);
  console.log(`🏠 Hostname: ${window.location.hostname}`);
  console.log(`🌍 Environment: ${config.ENVIRONMENT_NAME}`);
  console.log(`🔗 API Base URL: ${config.API_BASE_URL}`);
  console.log(`🌐 Origin: ${config.ORIGIN}`);
  console.log(`🔐 SSO Client ID: ${config.SSO_CLIENT_ID}`);
  console.log(`🔑 HMAC ID: ${config.HMAC_ID}`);
  console.log(`🔑 HMAC Key: ${config.HMAC_KEY.substring(0, 8)}...`);
  if (config.HMAC_STATIC_TOKEN) {
    console.log(`🔑 Static Token: ${config.HMAC_STATIC_TOKEN}`);
  }
  console.log(`🏭 Is Production: ${config.IS_PRODUCTION}`);
  console.log('='.repeat(60));
  
  if (config.ENVIRONMENT_NAME === 'LOCAL') {
    console.log('💻 Running in LOCAL development mode');
  } else if (config.ENVIRONMENT_NAME === 'DEV') {
    console.log('🔧 Running in DEV environment');
  } else if (config.ENVIRONMENT_NAME === 'UAT') {
    console.log('🧪 Running in UAT environment');
  } else if (config.ENVIRONMENT_NAME === 'PROD') {
    console.log('🚀 Running in PRODUCTION environment');
  }
}, 100); // Small delay to ensure window.location is available
