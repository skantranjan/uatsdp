import React, { useState } from 'react';

interface RoleCheckerConfigProps {
  onConfigChange: (config: { checkInterval: number; enabled: boolean }) => void;
  currentConfig: { checkInterval: number; enabled: boolean };
}

const RoleCheckerConfig: React.FC<RoleCheckerConfigProps> = ({ onConfigChange, currentConfig }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [config, setConfig] = useState(currentConfig);

  const handleSave = () => {
    onConfigChange(config);
    setIsOpen(false);
  };

  const intervalOptions = [
    { value: 10000, label: '10 seconds' },
    { value: 30000, label: '30 seconds' },
    { value: 60000, label: '1 minute' },
    { value: 300000, label: '5 minutes' },
    { value: 600000, label: '10 minutes' }
  ];

  if (!isOpen) {
    return (
      <div style={{
        position: 'fixed',
        top: '10px',
        right: '10px',
        zIndex: 1000
      }}>
        <button
          onClick={() => setIsOpen(true)}
          style={{
            background: '#007bff',
            color: 'white',
            border: 'none',
            padding: '8px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '12px'
          }}
        >
          Role Checker Config
        </button>
      </div>
    );
  }

  return (
    <div style={{
      position: 'fixed',
      top: '10px',
      right: '10px',
      background: 'white',
      border: '1px solid #ccc',
      borderRadius: '8px',
      padding: '16px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
      zIndex: 1001,
      minWidth: '250px'
    }}>
      <h4 style={{ margin: '0 0 12px 0', fontSize: '14px' }}>Role Checker Configuration</h4>
      
      <div style={{ marginBottom: '12px' }}>
        <label style={{ display: 'block', marginBottom: '4px', fontSize: '12px' }}>
          <input
            type="checkbox"
            checked={config.enabled}
            onChange={(e) => setConfig({ ...config, enabled: e.target.checked })}
            style={{ marginRight: '6px' }}
          />
          Enable Real-time Role Checking
        </label>
      </div>

      <div style={{ marginBottom: '12px' }}>
        <label style={{ display: 'block', marginBottom: '4px', fontSize: '12px' }}>
          Check Interval:
        </label>
        <select
          value={config.checkInterval}
          onChange={(e) => setConfig({ ...config, checkInterval: parseInt(e.target.value) })}
          style={{ width: '100%', padding: '4px', fontSize: '12px' }}
        >
          {intervalOptions.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      <div style={{ display: 'flex', gap: '8px' }}>
        <button
          onClick={handleSave}
          style={{
            background: '#28a745',
            color: 'white',
            border: 'none',
            padding: '6px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '12px'
          }}
        >
          Save
        </button>
        <button
          onClick={() => {
            setConfig(currentConfig);
            setIsOpen(false);
          }}
          style={{
            background: '#6c757d',
            color: 'white',
            border: 'none',
            padding: '6px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '12px'
          }}
        >
          Cancel
        </button>
      </div>
    </div>
  );
};

export default RoleCheckerConfig;
