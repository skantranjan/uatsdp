import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSSO } from '../hooks/useSSO';
import { useRoleChecker } from '../hooks/useRoleChecker';
import { useNavigate, useLocation } from 'react-router-dom';
import LoadingModal from './LoadingModal';
import ErrorModal from './ErrorModal';

interface AutoSSOProps {
  children: React.ReactNode;
}

const AutoSSO: React.FC<AutoSSOProps> = ({ children }) => {
  const { isAuthenticated, user } = useAuth();
  const { handleSSOLogin } = useSSO();
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [hasAttemptedAuth, setHasAttemptedAuth] = useState(false);
  const [lastKnownRole, setLastKnownRole] = useState<string | number | null>(null);

  // Enable real-time role checking
  useRoleChecker({
    checkInterval: 30000, // Check every 30 seconds
    enabled: isAuthenticated && !!user
  });

  // Check for role changes on page refresh
  useEffect(() => {
    const checkRoleChange = () => {
      if (isAuthenticated && user && user.role) {
        const currentRole = user.role;
        const storedRole = localStorage.getItem('lastKnownRole');
        
        console.log('🔍 Role Check: Current role:', currentRole);
        console.log('🔍 Role Check: Stored role:', storedRole);
        
        // If roles are different, redirect to appropriate landing page
        if (storedRole && storedRole !== currentRole.toString()) {
          console.log('🔍 Role Check: Role changed! Redirecting to appropriate landing page...');
          localStorage.setItem('lastKnownRole', currentRole.toString());
          
          // Force redirect to landing page to trigger role-based routing
          navigate('/landing', { replace: true });
          return;
        }
        
        // Update stored role
        localStorage.setItem('lastKnownRole', currentRole.toString());
        setLastKnownRole(currentRole);
      }
    };

    checkRoleChange();
  }, [isAuthenticated, user, navigate]);

  useEffect(() => {
    const performAutoSSO = async () => {
      // Skip if already authenticated or already attempted
      if (isAuthenticated || hasAttemptedAuth) {
        return;
      }

      console.log('🔍 AutoSSO: Starting authentication process...');
      setIsLoading(true);
      setHasAttemptedAuth(true);

      try {
        // Trigger SSO login
        await handleSSOLogin();
        
        // If we reach here, SSO was successful
        console.log('🔍 AutoSSO: Authentication successful');
        setIsLoading(false);
      } catch (error: any) {
        console.error('🔍 AutoSSO: Authentication failed:', error);
        setIsLoading(false);
        
        // Show error modal
        setErrorMessage('You are not authorized to access this application');
        setShowError(true);
      }
    };

    // Small delay to ensure app is fully loaded
    const timer = setTimeout(() => {
      performAutoSSO();
    }, 1000);

    return () => clearTimeout(timer);
  }, [isAuthenticated, hasAttemptedAuth, handleSSOLogin]);

  // Show loading modal while authenticating
  if (isLoading) {
    return <LoadingModal isVisible={true} />;
  }

  // Show error modal if authentication failed
  if (showError) {
    return (
      <ErrorModal 
        isVisible={true}
        message={errorMessage}
        onClose={() => setShowError(false)}
      />
    );
  }

  // Show children if authenticated or if no authentication attempt made yet
  return <>{children}</>;
};

export default AutoSSO;
