import React, { useEffect, useState } from 'react';
import { getEnvConfig } from '../config/environment';

const EnvironmentTest: React.FC = () => {
  const [environment, setEnvironment] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadEnvironment = () => {
      try {
        const config = getEnvConfig();
        setEnvironment(config);
        setIsLoading(false);
      } catch (error) {
        console.error('Error loading environment:', error);
        setIsLoading(false);
      }
    };

    loadEnvironment();
  }, []);

  const switchToDummyUat = () => {
    const currentUrl = new URL(window.location.href);
    currentUrl.searchParams.set('env', 'uat');
    window.location.href = currentUrl.toString();
  };

  const switchToLocal = () => {
    const currentUrl = new URL(window.location.href);
    currentUrl.searchParams.delete('env');
    window.location.href = currentUrl.toString();
  };

  if (isLoading) {
    return (
      <div className="container mt-5">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Loading environment configuration...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-12">
          <h1 className="mb-4">🧪 Environment Testing Page</h1>
          
          <div className="alert alert-info">
            <h5>Environment Detection Test</h5>
            <p>This page helps you test different environment configurations locally.</p>
          </div>

          <div className="row">
            <div className="col-md-6">
              <div className="card">
                <div className="card-header">
                  <h5>Current Environment</h5>
                </div>
                <div className="card-body">
                  {environment && (
                    <div>
                      <p><strong>Environment Name:</strong> <span className={`badge ${environment.ENVIRONMENT_NAME === 'DUMMY_UAT' ? 'bg-warning' : environment.ENVIRONMENT_NAME === 'LOCAL' ? 'bg-primary' : 'bg-success'}`}>{environment.ENVIRONMENT_NAME}</span></p>
                      <p><strong>API Base URL:</strong> <code>{environment.API_BASE_URL}</code></p>
                      <p><strong>Origin:</strong> <code>{environment.ORIGIN}</code></p>
                      <p><strong>SSO Client ID:</strong> <code>{environment.SSO_CLIENT_ID}</code></p>
                      <p><strong>HMAC ID:</strong> <code>{environment.HMAC_ID}</code></p>
                      <p><strong>HMAC Key:</strong> <code>{environment.HMAC_KEY.substring(0, 8)}...</code></p>
                      {environment.HMAC_STATIC_TOKEN && (
                        <p><strong>Static Token:</strong> <code>{environment.HMAC_STATIC_TOKEN}</code></p>
                      )}
                      <p><strong>Is Production:</strong> <span className={`badge ${environment.IS_PRODUCTION ? 'bg-danger' : 'bg-success'}`}>{environment.IS_PRODUCTION ? 'Yes' : 'No'}</span></p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="col-md-6">
              <div className="card">
                <div className="card-header">
                  <h5>Environment Switching</h5>
                </div>
                <div className="card-body">
                  <p>Switch between different environment configurations:</p>
                  
                  <div className="d-grid gap-2">
                    <button 
                      className="btn btn-warning" 
                      onClick={switchToDummyUat}
                      disabled={environment?.ENVIRONMENT_NAME === 'DUMMY_UAT'}
                    >
                      🧪 Switch to Dummy UAT
                    </button>
                    
                    <button 
                      className="btn btn-primary" 
                      onClick={switchToLocal}
                      disabled={environment?.ENVIRONMENT_NAME === 'LOCAL'}
                    >
                      💻 Switch to Local
                    </button>
                  </div>

                  <hr />
                  
                  <h6>Manual URL Testing:</h6>
                  <p>You can also test by adding URL parameters:</p>
                  <ul>
                    <li><code>?env=uat</code> - Dummy UAT environment</li>
                    <li>No parameter - Local environment</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="row mt-4">
            <div className="col-12">
              <div className="card">
                <div className="card-header">
                  <h5>Console Commands</h5>
                </div>
                <div className="card-body">
                  <p>Open browser console (F12) and try these commands:</p>
                  <div className="bg-dark text-light p-3 rounded">
                    <code>getCurrentEnvironment()</code> - Show current environment<br/>
                    <code>testEnvironmentDetection()</code> - Test environment detection<br/>
                    <code>switchToDummyUat()</code> - Switch to dummy UAT<br/>
                    <code>switchToLocal()</code> - Switch to local
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnvironmentTest;
